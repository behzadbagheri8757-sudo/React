'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const appPath = path.resolve(__dirname, '../../../artifacts/bagheri-crm/src/App.tsx');
const app = fs.readFileSync(appPath, 'utf8');
const detailPath = path.resolve(__dirname, '../../../artifacts/bagheri-crm/src/InvoiceDetail.tsx');
const detailSource = fs.readFileSync(detailPath, 'utf8');
const marker = '    bridgeScript.textContent = `';
const start = app.indexOf(marker);
if (start < 0) throw new Error('bridge script marker not found');
const bodyStart = start + marker.length;
const end = app.indexOf('\n    `;', bodyStart);
if (end < 0) throw new Error('bridge script terminator not found');
const bridgeSource = app.slice(bodyStart, end);

let passed = 0;
let failed = 0;
function assert(name, condition) {
  if (condition) { passed++; console.log('ok  ' + name); }
  else { failed++; console.error('FAIL ' + name); }
}

const invoice = {
  id: 'inv-1', number: '1042', customerId: 'cust-1', buyerName: 'خریدار', date: '2026-11-16',
  total: 110, discount: 10, discountType: 'fixed', cashPaid: 20, cardPaid: 0,
  transferPaid: 0, checkPaid: 0, prevBalance: 50, newBalance: 140, visitId: 'visit-1',
  items: [{ id: 'line-1', productId: 'p-1', name: 'لوبیا چیتی', qty: 2, price: 60, buyPrice: 40, discount: 0 }],
  editHistory: [{ id: 'edit-1', editedAt: '2026-11-16T10:30:00.000Z', before: { total: 100 }, after: { total: 110 }, note: 'اصلاح تعداد' }]
};
const original = JSON.stringify(invoice);
const main = {
  querySelector(selector) {
    if (selector === '#inv-link-visit') return select;
    if (selector === '[data-inv-action="print"]') return printButton;
    if (selector === '[data-inv-action="link-visit"]') return linkButton;
    return null;
  }
};
const select = { value: '' };
let printClicks = 0;
let linkClicks = 0;
const printButton = { click() { printClicks++; } };
const linkButton = { click() { linkClicks++; } };
const context = {
  data: {
    invoices: [invoice],
    customers: [{ id: 'cust-1', name: 'فروشگاه نمونه', phone: '09120000000', visits: [{ id: 'visit-1', date: '2026-11-15', time: '12:30', result: 'ویزیت' }, { id: 'visit-2', date: '2026-11-10', result: 'سفارش' }] }],
    products: [{ id: 'p-1', name: 'لوبیا چیتی', packageWeight: 5 }]
  },
  invoiceEffectivePaid: () => 50,
  invoiceEffectiveRemain: () => 60,
  invoiceOnRecordPaid: (x) => (x.cashPaid || 0) + (x.cardPaid || 0) + (x.transferPaid || 0) + (x.checkPaid || 0),
  invoiceDiscountAmount: () => 10,
  invoiceAllocationTrace: () => ({
    onRecord: 20, linkedEventObservedTotal: 20, legacyOnInvoice: 0,
    incoming: [{ kind: 'cash', eventId: 'pay-1', date: '2026-11-16', amount: 30, path: 'linked', fromInvoiceId: null, fromInvoiceNumber: null }],
    incomingTotal: 30, incomingLinkedTotal: 30, incomingLinkedReturnTotal: 0,
    outgoing: [], outgoingTotal: 0, effectivePaid: 50, remain: 60
  }),
  createComputationContext: () => ({}),
  customerTotals: () => ({ balance: 200 }),
  faDate: (value) => 'FA:' + String(value || '').slice(0, 10),
  URLSearchParams,
  document: { getElementById(id) { return id === 'main' ? main : null; } },
  location: { hash: '#/invoice?id=inv-1' },
  console,
  Date,
  Math,
  Number,
  String,
  Array,
  Object,
  JSON,
  isFinite,
  setTimeout,
  clearTimeout
};
context.window = context;
vm.createContext(context);
vm.runInContext(bridgeSource, context, { timeout: 1000 });
const bridge = context.__BAGHERI_DASHBOARD_BRIDGE__;
const snap = bridge.getInvoiceDetailSnapshot('inv-1');
assert('snapshot found for an existing invoice', snap && snap.found === true);
assert('canonical effective paid and remain are passed through', snap.financial.paid === 50 && snap.financial.remain === 60);
assert('current customer balance remains a separate figure', snap.financial.currentCustomerBalance === 200);
assert('line quantity, unit and line total are read correctly', snap.items[0].qty === 2 && snap.items[0].unit === 'بسته 5' && snap.items[0].lineTotal === 120);
assert('canonical invoice discount and internal profit are exposed read-only', snap.invoice.discountAmount === 10 && snap.financial.profit === 30);
assert('allocation trace is passed through without recalculating allocations', snap.allocation.incomingTotal === 30 && snap.allocation.incoming[0].path === 'linked');
assert('linked visit and visit options are available', snap.visit.linkedId === 'visit-1' && snap.visit.options.length === 2);
assert('edit history is read-only and formatted', snap.editHistory[0].beforeTotal === 100 && snap.editHistory[0].afterTotal === 110 && snap.editHistory[0].editedAt.startsWith('FA:'));
assert('missing invoice returns not-found state', bridge.getInvoiceDetailSnapshot('missing').found === false);
assert('snapshot extraction does not mutate invoice data', JSON.stringify(invoice) === original);
assert('print action routes to existing legacy handler', bridge.runInvoiceAction('print', 'inv-1') === true && printClicks === 1);
assert('visit link action selects requested visit and invokes existing handler', bridge.runInvoiceAction('link-visit', 'inv-1', 'visit-2') === true && select.value === 'visit-2' && linkClicks === 1);
assert('action for a different invoice is rejected', bridge.runInvoiceAction('print', 'other-invoice') === false);
assert('new invoice detail is a full page without disclosure accordions', !/<details|<summary|<Accordion/i.test(detailSource));
assert('invoice route uses the new independent React page and hides legacy frame', app.includes("const useNewInvoiceDetail = route === '/invoice'") && app.includes('useNewInvoiceDetail && <InvoiceDetail'));
console.log(`\n${passed} passed, ${failed} failed`);
process.exitCode = failed ? 1 : 0;
