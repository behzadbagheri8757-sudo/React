// node tests/quick-view-summary/run.js — logic tests for buildCustomerVisitSummary (no DOM, no backup needed)
const fs=require('fs'),vm=require('vm'),path=require('path');
global.__x=1;const ROOT=path.join(__dirname,'..','..');
const RD=Date, FIXED=new RD('2026-11-04T10:00:00').getTime();
class FD extends RD{constructor(...a){a.length?super(...a):super(FIXED);} static now(){return FIXED;}}
const noop=()=>{};
const ctx={console,JSON,Math,Set,Map,Object,Array,String,Number,Boolean,RegExp,Error,Promise,isFinite,isNaN,parseInt,parseFloat,Symbol,Intl,Date:FD,
  setTimeout:noop,clearTimeout:noop,setInterval:noop,localStorage:{getItem:()=>null,setItem:noop,removeItem:noop},
  document:{getElementById:()=>null,createElement:()=>({}),addEventListener:noop,body:{}},navigator:{},location:{hash:''},addEventListener:noop,requestAnimationFrame:noop};
ctx.__QV_DEBUG=true;ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const run=(f,src)=>vm.runInContext(src,ctx,{filename:f});
['js/models.js','js/ui.js','js/calc.js','js/computation-bank.js'].forEach(f=>run(f,fs.readFileSync(path.join(ROOT,f),'utf8')));
const app=fs.readFileSync(path.join(ROOT,'js/app.js'),'utf8');
const i0=app.indexOf('window.BagheriPresent = (function'), i1=app.indexOf('function openAddVisit(cid){');
run('BagheriPresent',app.slice(i0,i1));
run('customer.js',fs.readFileSync(path.join(ROOT,'js/views/customer.js'),'utf8'));
const day=n=>{const d=new RD(FIXED);d.setDate(d.getDate()-n);return d.toISOString().slice(0,10);};
const fut=n=>day(-n);
let pass=0,fail=0;
function t(name,cond){ if(cond){pass++;console.log('ok   '+name);}else{fail++;console.log('FAIL '+name);} }
function setup(o){
  ctx.__d=Object.assign({products:[],customers:[],invoices:[],payments:[],checks:[],suppliers:[],inventoryLayers:[],analysisGroups:[]},o);
  run('seed','data = Object.assign(emptyData(), __d);');
  const c=ctx.createComputationContext({data:vm.runInContext('data',ctx)});
  return ctx.buildCustomerVisitSummary('c1',c);
}
const P=(id,name,extra)=>Object.assign({id,name,active:true,stockQty:10},extra||{});
const inv=(id,date,items,total)=>({id,number:id,customerId:'c1',date,total:total==null?1000:total,items:items||[{productId:'p1',qty:2,price:500}]});
const cust=visits=>[{id:'c1',name:'x',visits:visits||[]}];
const layers=ps=>ps.filter(p=>p.stockQty>0).map(p=>({id:'L'+p.id,productId:p.id,qtyRemaining:p.stockQty,status:'open'}));
const prods=[P('p1','کشمش'),P('p2','نخود',{stockQty:0}),P('p3','لوبیا',{stockQty:null}),P('p4','عدس',{active:false})];
const base=(extra)=>Object.assign({products:prods,customers:cust(),inventoryLayers:layers(prods)},extra);

let s=setup(base());
t('1 no invoices: no purchase, "خریدی ثبت نشده", no suggestions',!s.lastPurchase&&s.purchaseTiming.text==='خریدی ثبت نشده'&&!s.suggestedProducts.length);
s=setup(base({invoices:[inv('i1',day(10))]}));
t('2 one invoice: insufficient history',s.purchaseTiming.state==='insufficient'&&s.lastPurchase.daysSince===10);
s=setup(base({invoices:[inv('i1',day(60)),inv('i2',day(40)),inv('i3',day(20)),inv('i4',day(2))]}));
t('3a regular buyer: last purchase correct',s.lastPurchase.date===day(2)&&s.lastPurchase.amount===1000);
t('3b regular buyer ~20d, 2d ago → early',s.purchaseTiming.state==='early');
s=setup(base({invoices:[inv('i1',day(60)),inv('i2',day(40)),inv('i3',day(20)),inv('i4',day(0))]}));
s=setup(base({invoices:[inv('i1',day(90)),inv('i2',day(70)),inv('i3',day(50)),inv('i4',day(30))]}));
t('3c 30d since, avg 20 → due',s.purchaseTiming.state==='due');
s=setup(base({invoices:[inv('i1',day(30)),inv('i1b',day(30)),inv('i2',day(10))]}));
t('3d same-day invoices count as one purchase day → insufficient',s.purchaseTiming.state==='insufficient');
s=setup(base({invoices:[inv('i1',day(10)),inv('z',day(1),[],0)]}));
t('3e zero-total invoice is not a valid last purchase',s.lastPurchase.date===day(10));
s=setup(base({checks:[{id:'k1',customerId:'c1',status:'bounced',amount:500,dueDate:day(5)},{id:'k2',customerId:'c1',status:'pending',amount:100,dueDate:day(5)}],invoices:[inv('i1',day(5))]}));
t('4 bounced check without active signal → falls to overdue (signals absent in harness)',!!s.priorityAlert&&s.priorityAlert.kind==='overdue_check');
s=setup(base({checks:[{id:'k2',customerId:'c1',status:'pending',amount:100,dueDate:day(5)},{id:'k3',customerId:'c1',status:'pending',amount:100,dueDate:fut(1)}],invoices:[inv('i1',day(5))]}));
t('5 overdue outranks due-soon (warning)',s.priorityAlert.kind==='overdue_check'&&s.priorityAlert.level==='warning');
s=setup(base({checks:[{id:'k3',customerId:'c1',status:'pending',amount:100,dueDate:fut(2)},{id:'k4',customerId:'c1',status:'cleared',amount:100,dueDate:day(9)}],invoices:[inv('i1',day(5))]}));
t('5b due in 2 days → due_soon; cleared ignored',s.priorityAlert.kind==='due_soon_check');
s=setup(base({checks:[{id:'k3',customerId:'c1',status:'pending',amount:100,dueDate:fut(9)}]}));
t('5c due in 9 days → no alert',s.priorityAlert===null);
const items=ids=>ids.map(id=>({productId:id,qty:2,price:500}));
s=setup(base({invoices:[inv('i1',day(9),items(['p1','p2','p3','p4']))]}));
const ids=s.suggestedProducts.map(p=>p.productId);
t('6 stock 0 excluded',ids.indexOf('p2')<0);
t('7 stock null (unknown) kept',ids.indexOf('p3')>=0);
t('7b inactive excluded, max 2',ids.indexOf('p4')<0&&ids.length<=2);
const V=(date,time,pid,reaction,reason,src)=>({id:'v'+date+pid,date,time,offeredProducts:[{productId:pid,reaction,rejectionReason:reason,stockSource:src}]});
s=setup(base({customers:cust([V(day(12),'10:00','p1','rejected','still_stock','unknown')]),invoices:[inv('i1',day(30))]}));
t('9 last reaction rejected → shown with real text',s.productsToCheck.length===1&&/کشمش/.test(s.productsToCheck[0].text)&&/هنوز موجودی دارد/.test(s.productsToCheck[0].text));
t('9b product in check list is NOT also suggested',s.suggestedProducts.every(p=>p.productId!=='p1'));
s=setup(base({customers:cust([V(day(12),'10:00','p1','rejected','still_stock')]),invoices:[inv('i1',day(5))]}));
t('8 rejected then bought later → not shown',s.productsToCheck.length===0&&s.suggestedProducts.some(p=>p.productId==='p1'));
s=setup(base({customers:cust([V(day(12),'10:00','p1','deferred')]),invoices:[inv('i1',day(30))]}));
t('10 last reaction deferred → not shown',s.productsToCheck.length===0);
s=setup(base({customers:cust([V(day(20),'10:00','p1','rejected','price'),V(day(10),'10:00','p1','accepted')]),invoices:[inv('i1',day(30))]}));
t('11a rejected earlier, accepted later → not shown',s.productsToCheck.length===0);
s=setup(base({customers:cust([V(day(20),'10:00','p1','accepted'),V(day(10),'10:00','p1','rejected','competitor')]),invoices:[inv('i1',day(30))]}));
t('11b accepted earlier, rejected later → shown',s.productsToCheck.length===1);
t('output shape exact',Object.keys(s).sort().join()==='lastPurchase,priorityAlert,productsToCheck,purchaseTiming,suggestedProducts');
console.log('\n'+pass+' passed, '+fail+' failed');process.exit(fail?1:0);
