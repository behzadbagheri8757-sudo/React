'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const reportsPath = path.resolve(__dirname, '../../js/views/reports.js');
const reportsSource = fs.readFileSync(reportsPath, 'utf8');
const artifactReportsPath = path.resolve(__dirname, '../../../artifacts/bagheri-crm/public/legacy/js/views/reports.js');
const artifactReportsSource = fs.readFileSync(artifactReportsPath, 'utf8');
const componentPath = path.resolve(__dirname, '../../../artifacts/bagheri-crm/src/Reports.tsx');
const appPath = path.resolve(__dirname, '../../../artifacts/bagheri-crm/src/App.tsx');
const component = fs.readFileSync(componentPath, 'utf8');
const app = fs.readFileSync(appPath, 'utf8');

let passed = 0;
let failed = 0;
function assert(name, condition) {
  if (condition) { passed++; console.log('ok  ' + name); }
  else { failed++; console.error('FAIL ' + name); }
}

const fixture = {
  invoices: [
    { id: 'i-current-1', number: '101', customerId: 'c1', date: '2026-11-14', total: 1000, items: [{ productId: 'p1', name: 'عدس روس', qty: 10, price: 100, buyPrice: 70, discount: 0 }] },
    { id: 'i-current-2', number: '102', customerId: 'c2', date: '2026-11-15', total: 2000, items: [{ productId: 'p2', name: 'لوبیا چیتی', qty: 20, price: 100, buyPrice: 75, discount: 0 }] },
    { id: 'i-prev-week', number: '099', customerId: 'c1', date: '2026-11-07', total: 500, items: [{ productId: 'p1', name: 'عدس روس', qty: 5, price: 100, buyPrice: 70, discount: 0 }] },
    { id: 'i-nowruz', number: '200', customerId: 'c1', date: '2026-03-21', total: 300, items: [{ productId: 'p1', name: 'عدس روس', qty: 3, price: 100, buyPrice: 70, discount: 0 }] }
  ],
  payments: [
    { id: 'pay-cash', method: 'cash', date: '2026-11-15', amount: 400 },
    { id: 'pay-card', method: 'card', date: '2026-11-16', amount: 200 },
    { id: 'pay-return', method: 'return', date: '2026-11-23', invoiceId: 'i-current-2', customerId: 'c2', amount: 100, returnItems: [{ productId: 'p2', name: 'لوبیا چیتی', qty: 1, price: 100 }] }
  ],
  customers: [
    { id: 'c1', name: 'فروشگاه یک', visits: [{ id: 'v1', date: '2026-11-14' }] },
    { id: 'c2', name: 'فروشگاه دو', visits: [{ id: 'v2', date: '2026-11-15' }] }
  ],
  products: [
    { id: 'p1', name: 'عدس روس', stockQty: -2 },
    { id: 'p2', name: 'لوبیا چیتی', stockQty: 0 },
    { id: 'p3', name: 'نخود', stockQty: 2 }
  ],
  suppliers: [{ id: 's1', name: 'تأمین‌کننده یک' }]
};
const originalFixture = JSON.stringify(fixture);
const context = {
  data: fixture,
  SHAMSI_MONTH_NAMES: ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'],
  enToFaDigits: (value) => String(value),
  toman: (value) => String(Math.round(Number(value) || 0)),
  faDate: (value) => 'FA:' + String(value || '').slice(0, 10),
  isSameDay: (value, now) => String(value || '').slice(0, 10) === now.toISOString().slice(0, 10),
  isSameMonth: (value, now) => String(value || '').slice(0, 7) === now.toISOString().slice(0, 7),
  invoiceDiscountAmount: (invoice) => Number(invoice.discount) || 0,
  globalTotals: () => ({ customerDebt: 700, supplierDebt: 900, totalProfit: 1200, outstandingChecks: 250 }),
  inventoryValue: () => 4500,
  lowStockProducts: () => [fixture.products[2]],
  debtorList: () => [
    { c: fixture.customers[1], t: { balance: 500 } },
    { c: fixture.customers[0], t: { balance: 200 } }
  ],
  supplierTotals: () => ({ balance: 900 }),
  visitStats: undefined,
  commandCenterMetrics: (now) => {
    if (now.getFullYear() === 2026 && now.getMonth() === 2 && now.getDate() === 21) {
      return { jy: 1405, jm: 1, jd: 1, mtdSales: 300, salesDeltaPct: 10, priorDayCount: 1 };
    }
    return { jy: 1405, jm: 8, jd: 27, mtdSales: 3500, salesDeltaPct: 5, priorDayCount: 27 };
  },
  jalaliMonthLength: (jy, jm) => jm === 12 ? 29 : 31,
  isoToJalali: (iso) => String(iso).startsWith('2026-03-21') ? [1405, 1, 1] : [1405, 8, 23],
  gregorianToJalali: (y, m, d) => (y === 2026 && m === 3 && d === 21) ? [1405, 1, 1] : [1405, 8, 23],
  jalaliToISO: (jy, jm, jd) => `J:${jy}-${String(jm).padStart(2,'0')}-${String(jd).padStart(2,'0')}`,
  _ccJalaliParts: (date) => (date.getFullYear() === 2026 && date.getMonth() === 2 && date.getDate() === 21) ? { jy: 1405, jm: 1, jd: 1 } : { jy: 1405, jm: 8, jd: 27 },
  _ccPreviousJalaliMonth: (jy, jm) => jm === 1 ? { jy: jy - 1, jm: 12 } : { jy, jm: jm - 1 },
  Date, Math, Number, String, Array, Object, JSON, isFinite, console
};
context.visitStats = function(period, now) {
  const visits = fixture.customers.reduce((sum, customer) => sum + customer.visits.filter((visit) => {
    if (period === 'week') {
      const date = new Date(visit.date + 'T00:00:00');
      const start = new Date(now); const diff = (start.getDay() + 1) % 7; start.setHours(0,0,0,0); start.setDate(start.getDate() - diff);
      const end = new Date(start); end.setDate(end.getDate() + 7);
      return date >= start && date < end;
    }
    return true;
  }).length, 0);
  return { visits, linked: 1, linkedEver: 1 };
};
context.window = context;
vm.createContext(context);
vm.runInContext(reportsSource, context, { timeout: 1000 });
const view = context.ReportsView;
assert('ReportsView exposes read-only snapshot API', !!view && typeof view.getSnapshot === 'function');
assert('artifact and reference reports scripts stay synchronized', reportsSource === artifactReportsSource);

const week = view.getSnapshot('week', new Date('2026-11-18T12:00:00'));
assert('week snapshot filters the current Saturday-based week', week.sales === 3000 && week.count === 2);
assert('week comparison range shows exact previous equivalent dates', week.range.compareStart === '2026-11-07' && week.range.compareEnd === '2026-11-11');
assert('week snapshot separates cash/card/transfer receipts', week.collections.byMethod.cash === 400 && week.collections.byMethod.card === 200 && week.collections.received === 600);
assert('return is attributed to original invoice period and reported separately', week.returnsTotal === 100 && week.netSales === 2900);
assert('top products apply only return rows with product detail', week.topProducts.some((item) => item.productId === 'p2' && item.revenue === 1900));
assert('debtors and supplier balances are read from existing helper results', week.collections.topDebtors[0].balance === 500 && week.financial.topSuppliers[0].balance === 900);
assert('inventory exception buckets remain separate', week.inventory.negative === 1 && week.inventory.zero === 1 && week.inventory.low === 1);
assert('visit metrics are surfaced without attributing unlinked invoices', week.field.visits === 2 && week.field.linked === 0 && week.field.linkedEver === 0);

const normalMonth = view.getSnapshot('month', new Date('2026-11-18T12:00:00'));
assert('month snapshot shows exact current and previous Jalali elapsed-day ranges', normalMonth.range.start === 'J:1405-08-01' && normalMonth.range.compareStart === 'J:1405-07-01' && normalMonth.range.compareEnd === 'J:1405-07-27');
const today = view.getSnapshot('today', new Date('2026-11-18T12:00:00'));
assert('today period does not invent a comparison range', today.comparison === null && today.range.start === '2026-11-18' && today.range.end === '2026-11-18');
const all = view.getSnapshot('all', new Date('2026-11-18T12:00:00'));
assert('all-time report includes all invoices and starts at the first invoice date', all.count === 4 && all.range.start === '2026-03-21' && all.comparison === null);

const nowruz = view.getSnapshot('month', new Date('2026-03-21T12:00:00'));
assert('Jalali Farvardin comparison crosses to previous Jalali year', nowruz.range.start === 'J:1405-01-01' && nowruz.range.compareStart === 'J:1404-12-01');
assert('Jalali new-year comparison end uses elapsed day count from canonical metrics', nowruz.range.compareEnd === 'J:1404-12-01');
assert('report snapshot does not mutate the source data', JSON.stringify(fixture) === originalFixture);
assert('React reports screen is independent and contains no disclosure accordion', !/<details|<summary|<Accordion/i.test(component));
assert('reports route renders the new React page and hides the legacy iframe', app.includes("const useNewReports = route === '/reports'") && app.includes('useNewReports && <Reports') && app.includes('|| useNewReports'));
assert('reports bridge delegates to the existing ReportsView snapshot helper', app.includes('g.ReportsView.getSnapshot(period || \'month\')'));

console.log(`\n${passed} passed, ${failed} failed`);
process.exitCode = failed ? 1 : 0;
