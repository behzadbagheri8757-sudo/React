/* Audit regression tests (read-only): real backup + real engine files in a vm.
   usage:  BAGHERI_BACKUP=/path/baqeri-backup-2026-10-27_2.json [CRM_ROOT=/path/to/build] node tests/audit-v7_8/run_all.js
   The backup is only READ. No browser (iPhone/Safari) is involved. */
const H=require('./harness');const fs=require('fs');
const bk=JSON.parse(fs.readFileSync(H.BACKUP,'utf8'));
const NOW='2026-10-28T09:00:00Z';
let pass=0,fail=0;
function ok(name,cond,extra){ if(cond){pass++;console.log('  PASS',name);} else {fail++;console.log('  FAIL',name,extra!==undefined?('-> '+extra):'');} }
const fresh=()=>H.load({now:NOW}).ctx;
const cid=n=>bk.customers.find(c=>c.name===n).id;
const prods=Object.fromEntries(bk.products.map(p=>[p.id,p]));

console.log('ITEM 1 — ACK vs real product family');
{
  const E=fresh();
  const A1='ack_mvp3vr86_nd0mek', A2='ack_mvqbai2q_ra3w17';
  const acks=bk.intelligence.seller_acks;
  const a1=acks.find(a=>a.id===A1), a2=acks.find(a=>a.id===A2);
  ok('records exist in backup, stored familyId is the raw product id',a1&&a2&&a1.familyId==='mrzb8lzhshzon'&&a2.familyId==='mrzb8lzhshzon');
  ok('product now belongs to group mvqi0q6nofbk4',prods['mrzb8lzhshzon'].analysisGroupId==='mvqi0q6nofbk4');
  const grp='mvqi0q6nofbk4';
  const mkSig=(pid)=>({category:'SKU_DELAY',type:'risk',severity:'high',sourceLevel:'sku',status:'active',productId:pid,familyId:grp});
  const e1=E.getAckEffectForSignal(mkSig('mrzb8lzhshzon'),E.getActiveAcksForCustomer('ms0p79juqfwgt'));
  ok('A1 (ms0p79juqfwgt) matches a same-family signal',!!e1&&e1.ackIds.indexOf(A1)>=0,JSON.stringify(e1));
  const e2=E.getAckEffectForSignal(mkSig('mrzb8lzhshzon'),E.getActiveAcksForCustomer('ms1je1i5sqt71'));
  ok('A2 (Chelsea ms1je1i5sqt71) matches a same-family signal',!!e2&&e2.ackIds.indexOf(A2)>=0,JSON.stringify(e2));
  const r=E.calculateCustomerRisk(cid('چلسی مارکت'),null);
  const sig=r.signals.find(s=>s.category==='COMBINED_SKU_DETERIORATION');
  ok('Chelsea real signal receives the ACK risk delta',sig&&sig.ackRiskDelta===10&&sig.ackIds.indexOf(A2)>=0,sig&&sig.ackRiskDelta);
  // a signal of ANOTHER family must never match
  const other=E.getAckEffectForSignal(Object.assign(mkSig('mrzb0dnuubmmi'),{familyId:'mrzb0dnuubmmi'}),E.getActiveAcksForCustomer('ms1je1i5sqt71'));
  ok('different family is not matched',!other||other.ackIds.indexOf(A2)<0);
  // stored records are never modified
  const stored=JSON.parse(E.localStorage.getItem('bagheri_seller_acks_v1')).find(a=>a.id===A2);
  ok('stored ACK record untouched (familyId still raw)',stored.familyId==='mrzb8lzhshzon');
  // a purchase of the product still clears a legacy (raw-id) ACK, exactly like any other ACK
  const R=fresh();
  const rr=R.reconcileAcksAfterInvoice('ms1je1i5sqt71',[{productId:'mrzb8lzhshzon',qty:3}]);
  ok('purchase of the product supersedes the legacy-family ACK',rr.superseded.indexOf(A2)>=0,JSON.stringify(rr));
  // ungrouped products: identical output to the stored record (no behaviour change)
  let diffs=0,checked=0;
  bk.customers.forEach(c=>E.getActiveAcksForCustomer(c.id).forEach(a=>{
    const orig=acks.find(x=>x.id===a.id); if(!orig||a.scope!=='product')return; checked++;
    if(a.familyId!==orig.familyId){ if(!prods[orig.productId]||!prods[orig.productId].analysisGroupId) diffs++; }
  }));
  ok('ungrouped-product ACKs are returned unchanged ('+checked+' checked)',diffs===0,diffs);
}

console.log('ITEM 2 — Watch active + still_stock (data inconsistency)');
{
  const E=fresh(); const ID='wo_mu60q0pw_lg5l9zn';
  const row=(E.getActiveWatchOccurrences('ms1je1i5sqt71')||[]).find(o=>o.id===ID);
  ok('inconsistent row present in the real backup (active, reason still_stock, no resolution/suppression)',row&&row.reason.code==='still_stock'&&!row.resolution&&!row.suppression);
  let bad=0,calls=0;
  ['still_stock','no_need','follow_up_later'].forEach(code=>{
    const F=fresh();
    bk.watchLifecycle.occurrences.filter(o=>o.status==='active'&&!o.reason).forEach(o=>{
      const r=F.recordWatchReason(o.id,code,'',code==='follow_up_later'?'2026-11-05':undefined); calls++;
      if(!(r&&r.status==='dismissed'&&r.resolution&&r.suppression&&r.reason.code===code)) bad++;
    });
  });
  ok('current recordWatchReason always closes the occurrence ('+calls+' calls) => shape NOT reproducible',bad===0,bad);
  const legacy=bk.watchLifecycle.occurrences.filter(o=>['still_stock','no_need'].indexOf((o.reason||{}).code)>=0&&!o.suppression);
  const modern=bk.watchLifecycle.occurrences.filter(o=>((o.resolution||{}).type||'').indexOf('seller_')===0);
  const earliestModern=modern.map(o=>o.reason.recordedAt).sort()[0];
  ok('reported row predates the earliest row closed by current code (legacy-build artefact is likely, not proven)',row.reason.recordedAt<earliestModern,row.reason.recordedAt+' vs '+earliestModern);
  console.log('  INFO  rows with decision reason but no suppression:',legacy.length,'| NOT PROVEN -> no code change');
}

console.log('ITEM 3 — growth consistency in risk level');
{
  const E=fresh();
  ['سوپر سعید','اقای جمشیدی','چلسی مارکت'].forEach(n=>{
    const r=E.calculateCustomerRisk(cid(n),null);
    ok(n+' (growing account, SKU-only risk) is no longer high/critical',r.level==='medium'&&r.score<=49,r.level+' '+r.score);
    ok(n+' keeps its SKU risk signal untouched',r.signals.some(s=>s.type==='risk'&&s.sourceLevel==='sku'));
  });
  ['تهران مارکت','شمال مارکت','آدرین مارکت','سوپر آفتاب ۲','سوپر پنج گل','سوپر امین رادمهر','چلک مارکت','سوپر هانی مارکت'].forEach(n=>{
    ok(n+' (real account-level risk) stays critical',E.calculateCustomerRisk(cid(n),null).level==='critical');
  });
  // synthetic scenarios through the real risk.js
  const mk=(cat,type,sev,lvl,status,extra)=>Object.assign({customerId:'X',category:cat,type:type,severity:sev,sourceLevel:lvl,status:status},extra||{});
  const run=sigs=>{ E.extractCustomerSignals=function(){return sigs.map(s=>Object.assign({},s));}; return E.calculateCustomerRisk('X_'+Math.random(),null); };
  const growth=mk('PURCHASE_GROWTH','opportunity','high','account','active');
  ok('S1 SKU critical, no growth => not capped',run([mk('SKU_DELAY','risk','critical','sku','active')]).score===100);
  ok('S2 SKU critical + growth => capped at 49 (medium)',(function(r){return r.score===49&&r.level==='medium';})(run([mk('SKU_DELAY','risk','critical','sku','active'),growth])));
  ok('S3 account risk + growth => NOT capped',run([mk('BEHIND_PATTERN','risk','high','account','active'),mk('KEY_PRODUCT_LOST','risk','high','account','active'),growth]).level==='critical');
  ok('S4 CHECK_BOUNCED + growth => NOT capped',run([mk('CHECK_BOUNCED','risk','critical','account','active'),growth]).score===100);
  ok('S5 growth still pending => NOT capped',run([mk('SKU_DELAY','risk','critical','sku','active'),mk('PURCHASE_GROWTH','opportunity','high','account','pending')]).score===100);
  ok('S6 low SKU risk + growth => unchanged (below cap)',run([mk('SKU_FREQUENCY_DROP','risk','low','sku','active'),growth]).score===20);
  ok('S7 signals array not mutated/filtered',run([mk('SKU_DELAY','risk','critical','sku','active'),growth]).signals.length===2);
}

console.log('ITEM 4 — "الان" consistent with the action\'s signal');
{
  const E=fresh();
  const rows=E.calculateAllActions(null).filter(x=>x.type==='customer');
  let wrong=0;
  rows.forEach(x=>{
    const cat=x.primarySignal&&x.primarySignal.category, w=x.whyNow||'';
    const visitText=/عقب‌افتاده|از آخرین ویزیت|ویزیت امروز/.test(w);
    const visitSig=['LONG_NO_VISIT','VISIT_OVERDUE','VISIT_CONVERSION_LOW','CONSECUTIVE_NO_ORDER'].indexOf(cat)>=0;
    if(visitText&&!visitSig) wrong++;
  });
  ok('no non-visit action explains itself with visit lateness ('+rows.length+' real rows)',wrong===0,wrong);
  const by=n=>rows.find(x=>x.name===n);
  ok('purchase-decline row cites the 30d vs previous-30d sales',/^فروش ۳۰ روز اخیر/.test(by('آدرین مارکت').whyNow),by('آدرین مارکت').whyNow);
  ok('behind-pattern row cites last purchase vs usual interval',/^آخرین خرید .* فاصلهٔ معمول/.test(by('سوپر هانی مارکت').whyNow),by('سوپر هانی مارکت').whyNow);
  // synthetic primary signals for categories absent from the real queue. The private
  // _customerWhyNow is exposed ONLY inside this test vm (the product file is not modified).
  const vm=require('vm'),path=require('path');
  const src=fs.readFileSync(path.join(H.ROOT,'js/intelligence/action.js'),'utf8').replace('global.calculateAllActions = calculateAllActions;','global.calculateAllActions = calculateAllActions; global.__whyNow = _customerWhyNow;');
  vm.runInContext(src,E);
  const target=rows[0].customerId;
  const forced=sig=>E.__whyNow(target,null,sig);
  ok('CHECK_BOUNCED => "N چک برگشتی ثبت‌شده"',forced({category:'CHECK_BOUNCED',value:2})==='۲ چک برگشتی ثبت‌شده',forced({category:'CHECK_BOUNCED',value:2}));
  ok('PAYMENT_OVERDUE => overdue check wording',/سررسیدگذشته/.test(forced({category:'PAYMENT_OVERDUE',value:1})));
  ok('SKU_DELAY with evidence => product gap vs cycle',/«عدس» ۲۴ روز پیش؛ چرخهٔ معمول خرید ۹ روز/.test(forced({category:'SKU_DELAY',productName:'عدس',evidence:{daysSinceLast:24,typicalCycle:9}})),forced({category:'SKU_DELAY',productName:'عدس',evidence:{daysSinceLast:24,typicalCycle:9}}));
  ok('SKU signal WITHOUT evidence => neutral (nothing invented)',forced({category:'SKU_FREQUENCY_DROP',productName:'عدس',evidence:{}})==='نیاز به پیگیری');
  ok('KEY_PRODUCT_LOST => neutral',forced({category:'KEY_PRODUCT_LOST'})==='نیاز به پیگیری');
  ok('VISIT_OVERDUE keeps visit timing (or neutral when none)',/ویزیت|نیاز به پیگیری/.test(forced({category:'VISIT_OVERDUE'})));
}

console.log('ITEM 5 — eligibility drops the winner without promoting the next candidate');
{
  const E=fresh(); let dropped=[];
  bk.customers.filter(c=>c.active!==false).forEach(c=>{
    const a=E.calculateCustomerAction(c.id,null,{ctx:null}); const p=E.calculateCustomerPriority(c.id,{});
    const sev=(p.signals||[]).some(s=>s.category==='PURCHASE_DECLINE_SEVERE'&&s.status!=='pending');
    if(a.actionType==='no_action'&&sev) dropped.push(c.name);
  });
  ok('behaviour documented by the code contract (kept by design): affected real customers = '+dropped.join('، '),dropped.length===2&&dropped.indexOf('تهران مارکت')>=0&&dropped.indexOf('سوپر آفتاب ۲')>=0,dropped.length);
}

console.log('\nRESULT: '+pass+' passed, '+fail+' failed');
process.exit(fail?1:0);
