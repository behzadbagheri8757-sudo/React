// node tests/payment-promises/run.js — logic tests for «وعدهٔ پرداخت» (no DOM, no IndexedDB)
const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.join(__dirname,'..','..');
const RD=Date, FIXED=new RD('2026-11-10T10:00:00').getTime();
class FD extends RD{constructor(...a){a.length?super(...a):super(FIXED);} static now(){return FIXED;}}
const noop=()=>{};
const ctx={console,JSON,Math,Set,Map,Object,Array,String,Number,Boolean,RegExp,Error,Promise,isFinite,isNaN,parseInt,parseFloat,Symbol,Intl,Date:FD,
  setTimeout:noop,clearTimeout:noop,setInterval:noop,localStorage:{getItem:()=>null,setItem:noop,removeItem:noop},
  document:{getElementById:()=>null,createElement:()=>({}),addEventListener:noop,body:{},readyState:'complete'},navigator:{},location:{hash:''},addEventListener:noop,requestAnimationFrame:noop,
  indexedDB:{},MutationObserver:undefined};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
const run=(f,src)=>vm.runInContext(src,ctx,{filename:f});
['js/models.js','js/ui.js','js/db.js','js/calc.js','js/computation-bank.js','js/payment-promises.js','js/views/payment-promises.js','js/backup.js']
  .forEach(f=>run(f,fs.readFileSync(path.join(ROOT,f),'utf8')));
// persistence stubs (the real saveData needs IndexedDB)
run('stubs','var __saves=0; saveData=async function(){__saves++;}; restoreDataInPlace=function(s){ reconcileRestoreGraph(data,s); };');

let pass=0,fail=0;
function t(name,cond){ if(cond){pass++;console.log('ok   '+name);}else{fail++;console.log('FAIL '+name);} }
const day=n=>{const d=new RD(FIXED);d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);}; // +n days from 2026-11-10
const TODAY=day(0);
function seed(extra){
  ctx.__d=Object.assign({customers:[{id:'c1',name:'نور',active:true,visits:[]},{id:'c2',name:'رضایی',active:true,visits:[]}],
    products:[],invoices:[],payments:[],checks:[],suppliers:[],inventoryLayers:[],analysisGroups:[],paymentPromises:[]},extra||{});
  run('seed','data = Object.assign(emptyData(), __d);');
  return vm.runInContext('data',ctx);
}
const PP=()=>ctx.PaymentPromises;
(async()=>{
  // ---- 1. register ----
  let d=seed();
  let r=PP().add(d,'c1',{amount:5000000,promiseDate:day(3),note:'پنجشنبه'},TODAY);
  t('1a promise is registered (pending, date=today)',r.ok&&d.paymentPromises.length===1&&r.promise.status==='pending'&&r.promise.date===TODAY);
  t('1b past promiseDate rejected',!PP().add(d,'c1',{amount:1,promiseDate:day(-1)},TODAY).ok);
  t('1c today is allowed',PP().add(d,'c2',{amount:0,promiseDate:TODAY},TODAY).ok);
  t('1d negative / NaN amount rejected',!PP().add(d,'c1',{amount:-5,promiseDate:day(2)},TODAY).ok&&!PP().add(d,'c1',{amount:'x',promiseDate:day(2)},TODAY).ok);
  t('1e unknown customer rejected',!PP().add(d,'nope',{amount:1,promiseDate:day(2)},TODAY).ok);
  const ro=await PP().commit(dd=>PP().add(dd,'c1',{amount:1000,promiseDate:day(2)}));
  t('1f commit() saves through saveData',ro.ok&&vm.runInContext('__saves',ctx)===1);

  // ---- 2. normalizeData ----
  d=seed(); PP().add(d,'c1',{amount:5000000,promiseDate:day(3),note:'x'},TODAY);
  let n=ctx.normalizeData(JSON.parse(JSON.stringify(d)));
  t('2a normalizeData keeps the promise intact',n.paymentPromises.length===1&&n.paymentPromises[0].amount===5000000&&n.paymentPromises[0].status==='pending'&&n.paymentPromises[0].keptAt===null);
  const old=JSON.parse(JSON.stringify(d)); delete old.paymentPromises;
  t('2b old data without the field → []',Array.isArray(ctx.normalizeData(old).paymentPromises)&&ctx.normalizeData(old).paymentPromises.length===0);
  const dirty=JSON.parse(JSON.stringify(d)); dirty.paymentPromises.push({id:'bad',customerId:'c1',promiseDate:'nonsense'},{id:'bad2',promiseDate:day(1)});
  t('2c corrupt rows are dropped, valid kept',ctx.normalizeData(dirty).paymentPromises.length===1);
  const str=JSON.parse(JSON.stringify(d)); str.paymentPromises[0].amount='7500000'; str.paymentPromises[0].status='weird';
  n=ctx.normalizeData(str);
  t('2d numeric string → number, unknown status → pending',n.paymentPromises[0].amount===7500000&&n.paymentPromises[0].status==='pending');

  // ---- 3. backup validation ----
  var bk=()=>({products:[],customers:[{id:'c1',name:'a'}],invoices:[],payments:[],checks:[],suppliers:[],schemaVersion:3,inventoryLayers:[],regions:[],routes:[],neighborhoods:[]});
  let b=bk(); t('3a OLD backup (no paymentPromises) is accepted',ctx.validateBackupShape(b)===true);
  const P=(o)=>Object.assign({id:'p1',customerId:'c1',date:TODAY,promiseDate:day(2),amount:100,note:'',status:'pending',keptAmount:null,keptAt:null,createdAt:new RD(FIXED).toISOString()},o||{});
  b=bk(); b.paymentPromises=[P()]; t('3b valid promise accepted',ctx.validateBackupShape(b)===true);
  b=bk(); b.paymentPromises=[P({customerId:'zzz'})]; t('3c unknown customer rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.paymentPromises=[P({promiseDate:'1405/01/01'})]; t('3d bad promiseDate rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.paymentPromises=[P({amount:-1})]; t('3e negative amount rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.paymentPromises=[P({status:'lost'})]; t('3f unknown status rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.paymentPromises=[P({status:'kept',keptAmount:50,keptAt:'2026-11-10T10:00:00.000Z'})]; t('3g kept with amount+ISO accepted',ctx.validateBackupShape(b)===true);
  b=bk(); b.paymentPromises=[P({keptAt:'yesterday'})]; t('3h non-ISO keptAt rejected',ctx.validateBackupShape(b)===false);
  b=bk(); b.paymentPromises=[P(),P()]; t('3i duplicate ids rejected',ctx.validateBackupShape(b)===false);

  // ---- 4. dashboard source + attention ----
  d=seed({invoices:[{id:'i1',number:1001,customerId:'c1',date:day(-30),total:30000000,items:[],dueDate:day(-5)}]});
  const attOf=()=>ctx.createComputationContext({data:d}).receivableAttention();
  t('4a baseline: c1 is in «نیازمند پیگیری»',attOf().rows.some(x=>x.customerId==='c1'));
  PP().add(d,'c1',{amount:5000000,promiseDate:day(3)},TODAY);
  t('4b future promise snoozes the generic follow-up',!attOf().rows.some(x=>x.customerId==='c1')&&!!attOf().promisedByCustomerId.c1);
  d.paymentPromises[0].promiseDate=day(-2);
  t('4c overdue promise: dashboard sees it',PP().dueList(d,TODAY).length===1&&PP().phase(d.paymentPromises[0],TODAY).kind==='overdue'&&PP().phase(d.paymentPromises[0],TODAY).days===2);
  t('4d …and it is not duplicated in the generic list',!attOf().rows.some(x=>x.customerId==='c1'));
  PP().markBroken(d,d.paymentPromises[0].id,TODAY);
  t('4e broken promise → customer returns to the generic follow-up',attOf().rows.some(x=>x.customerId==='c1'));
  d=seed(); PP().add(d,'c1',{amount:1,promiseDate:day(5)},TODAY);
  t('4f future promise is not in dueList; today is',PP().dueList(d,TODAY).length===0&&(PP().add(d,'c2',{amount:1,promiseDate:TODAY},TODAY),PP().dueList(d,TODAY).length===1));

  // ---- 5. supersede ----
  d=seed(); const a=PP().add(d,'c1',{amount:1000,promiseDate:day(2)},TODAY).promise;
  const o2=PP().add(d,'c2',{amount:1000,promiseDate:day(2)},TODAY).promise;
  const b2=PP().add(d,'c1',{amount:2000,promiseDate:day(6)},TODAY).promise;
  t('5a new promise supersedes the previous pending one (same customer)',a.status==='superseded'&&b2.status==='pending'&&PP().active('c1',d).id===b2.id);
  t('5b other customers are untouched',o2.status==='pending');

  // ---- 6. «دریافت شد» ----
  d=seed({payments:[]}); const p6=PP().add(d,'c1',{amount:5000000,promiseDate:day(1)},TODAY).promise;
  t('6a no payment → not kept (keep() refuses)',!PP().keep(d,p6.id,null).ok&&!PP().keep(d,p6.id,{amount:0,customerId:'c1'}).ok&&p6.status==='pending');
  t('6b payment of another customer → not kept',!PP().keep(d,p6.id,{amount:1000,customerId:'c2'}).ok&&p6.status==='pending');
  const pay={id:'pay1',customerId:'c1',amount:3000000,method:'cash',date:TODAY};
  d.payments.push(pay); const k=PP().keep(d,p6.id,pay);
  t('6c payment saved together → kept with keptAmount/keptAt',k.ok&&p6.status==='kept'&&p6.keptAmount===3000000&&!!p6.keptAt);
  t('6d a kept promise cannot be kept/broken again',!PP().keep(d,p6.id,pay).ok&&!PP().markBroken(d,p6.id,day(9)).ok);
  const p6b=PP().add(d,'c2',{amount:1,promiseDate:day(1)},TODAY).promise;
  t('6e «انجام نشد» only after the date has passed',!PP().markBroken(d,p6b.id,TODAY).ok&&PP().markBroken(d,p6b.id,day(2)).ok);
  const p6c=PP().add(d,'c1',{amount:1,promiseDate:day(1)},TODAY).promise;
  t('6f remove() deletes',PP().remove(d,p6c.id).ok&&!PP().byId(p6c.id,d));

  // ---- 7. amount=0 and money invariants ----
  d=seed({invoices:[{id:'i1',number:1001,customerId:'c1',date:day(-3),total:9000000,items:[]}]});
  const before=JSON.stringify(ctx.customerTotals('c1',ctx.createComputationContext({data:d})));
  const z=PP().add(d,'c1',{amount:'',promiseDate:day(2)},TODAY).promise;
  t('7a amount=0 renders «کل بدهی»',z.amount===0&&PP().amountLabel(z)==='کل بدهی'&&/کل بدهی/.test(ctx.PromiseUI.cardHtml('c1',9000000)));
  t('7b amount>0 renders the money',/ت/.test(PP().amountLabel({amount:5000000})));
  const after=JSON.stringify(ctx.customerTotals('c1',ctx.createComputationContext({data:d})));
  t('7c a promise never changes customerTotals (payTotal/balance)',before===after);
  t('7d customer card: debt & no promise → «ثبت وعده»; no debt → nothing',/data-pp-add/.test(ctx.PromiseUI.cardHtml('c2',500))&&ctx.PromiseUI.cardHtml('c2',0)==='');
  t('7e badges: 1 day → فردا, today → امروز, past → N روز از موعد',
    PP().badge({status:'pending',promiseDate:day(1)},TODAY).text==='فردا'&&PP().badge({status:'pending',promiseDate:TODAY},TODAY).text==='امروز'&&/از موعد/.test(PP().badge({status:'pending',promiseDate:day(-3)},TODAY).text));


  // ---- 8. «بستن بدون پرداخت» (dismiss) ----
  d=seed({invoices:[{id:'i1',number:1001,customerId:'c1',date:day(-30),total:30000000,items:[],dueDate:day(-5)}]});
  const p8=PP().add(d,'c1',{amount:5000000,promiseDate:day(2)},TODAY).promise;
  const payN=d.payments.length, tot8=JSON.stringify(ctx.customerTotals('c1',ctx.createComputationContext({data:d})));
  const r8=PP().dismiss(d,p8.id);
  t('8a dismiss: pending → kept, keptAmount stays null, keptAt set',r8.ok&&p8.status==='kept'&&p8.keptAmount===null&&!!p8.keptAt);
  t('8b dismiss creates no payment and changes no totals',d.payments.length===payN&&tot8===JSON.stringify(ctx.customerTotals('c1',ctx.createComputationContext({data:d}))));
  t('8c dismissed promise leaves dueList; debtor returns to the generic follow-up',PP().dueList(d,day(9)).length===0&&ctx.createComputationContext({data:d}).receivableAttention().rows.some(x=>x.customerId==='c1'));
  t('8d dismiss refuses non-pending promises',!PP().dismiss(d,p8.id).ok&&!PP().dismiss(d,'nope').ok);
  t('8e dismissed promise survives normalize + backup validation',(()=>{const n=ctx.normalizeData(JSON.parse(JSON.stringify(d)));const b=bk();b.customers=[{id:'c1',name:'a'}];b.paymentPromises=n.paymentPromises;return n.paymentPromises[0].keptAmount===null&&ctx.validateBackupShape(b)===true;})());
  t('8f history labels a dismissed promise (no «۰ ت»)',/پرداخت جداگانه/.test(ctx.PromiseUI.historyHtml('c1'))&&!/دریافت: ۰/.test(ctx.PromiseUI.historyHtml('c1')));

  // ---- 9. dashboard block ----
  d=seed();
  t('9a nothing due → no dashboard block',ctx.PromiseUI.dashboardHtml()==='');
  PP().add(d,'c1',{amount:20000000,promiseDate:day(-0)},TODAY); d.paymentPromises[0].promiseDate=day(-2);
  PP().add(d,'c2',{amount:5000000,promiseDate:TODAY},TODAY);
  let h=ctx.PromiseUI.dashboardHtml();
  t('9b overdue + today groups, one «دریافت شد» per row',/سررسیدگذشته/.test(h)&&/امروز/.test(h)&&(h.match(/data-pp-receive-quick/g)||[]).length===2);
  t('9c overdue group comes first and shows days late',h.indexOf('سررسیدگذشته')<h.indexOf('امروز')&&/از موعد/.test(h));
  t('9d rows link to the customer page',/#\/customer\?id=c1/.test(h)&&/#\/customer\?id=c2/.test(h));
  d.paymentPromises.length=0; d.customers.push(...Array.from({length:6},(_,i)=>({id:'x'+i,name:'m'+i,active:true,visits:[]})));
  for(let i=0;i<6;i++) PP().add(d,'x'+i,{amount:1,promiseDate:TODAY},TODAY);
  t('9e at most 5 rows are rendered',(ctx.PromiseUI.dashboardHtml().match(/data-pp-receive-quick/g)||[]).length===5);
  d.paymentPromises.length=0; PP().add(d,'c1',{amount:1,promiseDate:day(4)},TODAY);
  t('9f only-future promises → no dashboard block',ctx.PromiseUI.dashboardHtml()==='');

  console.log('\n'+pass+' passed, '+fail+' failed');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1);});
