'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');

(async function main() {
  let passed = 0;
  function check(name, fn) {
    fn();
    passed += 1;
    process.stdout.write(`PASS ${name}\n`);
  }

  const modelUrl = pathToFileURL(path.resolve(__dirname, '../../../artifacts/bagheri-crm/src/checks-model.js')).href;
  const model = await import(modelUrl);
  const baseRows = [
    { id:'c1', side:'customer', partyName:'فروشگاه آریا', checkNumber:'۱۲۳۴', amount:5000000, invoiceNumber:'۱۰۲', bank:'', note:'', status:'pending', statusLabel:'در جریان', dueDateRaw:'2026-11-20', dueDiff:0, rawDate:'', createdOrder:0, sourceIndex:0 },
    { id:'c2', side:'customer', partyName:'فروشگاه بهار', checkNumber:'5678', amount:2000000, invoiceNumber:'', bank:'', note:'', status:'cleared', statusLabel:'وصول‌شده', dueDateRaw:'2026-11-19', dueDiff:-1, rawDate:'', createdOrder:1, sourceIndex:1 },
    { id:'s1', side:'supplier', partyName:'تأمین الف', checkNumber:'B1', amount:7000000, invoiceNumber:'', bank:'ملت', note:'', status:'bounced', statusLabel:'برگشتی', dueDateRaw:'2026-11-18', dueDiff:-2, rawDate:'2026-11-01', createdOrder:0, sourceIndex:0 },
    { id:'s2', side:'supplier', partyName:'تأمین ب', checkNumber:'B2', amount:3000000, invoiceNumber:'', bank:'صادرات', note:'', status:'pending', statusLabel:'در جریان', dueDateRaw:'2026-11-23', dueDiff:3, rawDate:'2026-11-05', createdOrder:1, sourceIndex:1 },
  ];

  check('Persian and Arabic digits normalize to searchable Latin digits', () => {
    assert.equal(model.normalizeCheckSearch('چک ۱۲۳٤'), 'چک 1234');
  });
  check('customer and supplier ledgers stay isolated', () => {
    assert.deepEqual(model.filterCheckRows(baseRows, 'customer', '', 'all', 'dueAsc').map(x => x.id), ['c2','c1']);
    assert.deepEqual(model.filterCheckRows(baseRows, 'supplier', '', 'all', 'dueAsc').map(x => x.id), ['s1','s2']);
  });
  check('near-due filter includes pending checks through day three only', () => {
    assert.deepEqual(model.filterCheckRows(baseRows, 'supplier', '', 'dueSoon', 'dueAsc').map(x => x.id), ['s2']);
  });
  check('overdue filter excludes cleared and bounced checks', () => {
    assert.deepEqual(model.filterCheckRows(baseRows, 'customer', '', 'overdue', 'dueAsc'), []);
    assert.deepEqual(model.filterCheckRows(baseRows, 'supplier', '', 'overdue', 'dueAsc'), []);
  });
  check('bounced filter is available only for supplier checks', () => {
    assert.deepEqual(model.filterCheckRows(baseRows, 'supplier', '', 'bounced', 'dueAsc').map(x => x.id), ['s1']);
    assert.deepEqual(model.filterCheckRows(baseRows, 'customer', '', 'bounced', 'dueAsc'), []);
  });
  check('search matches Persian digits, party name, bank, and invoice number', () => {
    assert.equal(model.filterCheckRows(baseRows, 'customer', '۱۲۳۴', 'all', 'dueAsc').length, 1);
    assert.equal(model.filterCheckRows(baseRows, 'supplier', 'ملت', 'all', 'dueAsc').length, 1);
    assert.equal(model.filterCheckRows(baseRows, 'customer', '۱۰۲', 'all', 'dueAsc').length, 1);
  });
  check('amount sorting is deterministic', () => {
    assert.deepEqual(model.filterCheckRows(baseRows, 'supplier', '', 'all', 'amountDesc').map(x => x.id), ['s1','s2']);
  });
  check('summary uses face values and keeps statuses separate', () => {
    const summary = model.summarizeCheckRows(baseRows.filter(x => x.side === 'supplier'));
    assert.equal(summary.faceTotal, 10000000);
    assert.equal(summary.pendingFace, 3000000);
    assert.equal(summary.bouncedCount, 1);
    assert.equal(summary.dueSoonCount, 1);
  });

  const auditRoot = path.resolve(__dirname, '../../..');
  const calcSource = fs.readFileSync(path.join(auditRoot, 'original/js/calc.js'), 'utf8');
  const appSource = fs.readFileSync(path.join(auditRoot, 'artifacts/bagheri-crm/src/App.tsx'), 'utf8');
  const marker = 'bridgeScript.textContent = `';
  const start = appSource.indexOf(marker);
  assert.notEqual(start, -1, 'bridge script must exist');
  const bodyStart = start + marker.length;
  const bodyEnd = appSource.indexOf('\n    `;', bodyStart);
  assert.notEqual(bodyEnd, -1, 'bridge script closing delimiter must exist');
  const bridgeSource = appSource.slice(bodyStart, bodyEnd);

  const data = {
    customers: [{ id:'c-1', name:'فروشگاه آریا' }],
    invoices: [{ id:'inv-1', number:'102', customerId:'c-1', date:'2026-11-18' }],
    checks: [
      { id:'check-1', customerId:'c-1', amount:5000000, dueDate:'2026-11-20', checkNumber:'1234', status:'pending', invoiceId:'inv-1', debtAllocations:[{invoiceId:'inv-1',amount:5000000}] },
      { id:'check-2', customerId:'c-1', amount:2500000, dueDate:'2026-11-19', checkNumber:'5678', status:'cleared' },
    ],
    suppliers: [{ id:'sup-1', name:'تأمین الف', payments:[
      { id:'sup-check-1', method:'check', date:'2026-11-01', issueDate:'2026-11-01', dueDate:'2026-11-22', amount:0, faceAmount:7000000, status:'bounced', checkNumber:'B-1', bank:'ملت', note:'توضیح' },
      { id:'sup-check-2', method:'check', date:'2026-11-05', dueDate:'2026-11-23', amount:3000000, status:'pending', checkNumber:'B-2' },
      { id:'cash-1', method:'cash', date:'2026-11-05', amount:1000000, status:'cleared' },
    ] }],
  };
  const before = JSON.stringify(data);
  let toggleClicks = 0;
  const fakeButton = { getAttribute: (name) => name === 'data-toggle-check' ? 'check-1' : null, click: () => { toggleClicks += 1; } };
  const document = { getElementById: (id) => id === 'check-list' ? { querySelectorAll: () => [fakeButton] } : null };
  const window = { document };
  const context = vm.createContext({
    window, data, Date, Math, Number, String, Object, Array, isFinite,
    todayISO: () => '2026-11-20',
    faDate: (value) => String(value || ''),
  });
  vm.runInContext(calcSource, context, { filename:'original/js/calc.js' });
  vm.runInContext(bridgeSource, context, { filename:'App.tsx bridge' });
  const bridge = window.__BAGHERI_DASHBOARD_BRIDGE__;

  check('bridge snapshot maps customer checks and invoice references', () => {
    const snapshot = bridge.getChecksSnapshot();
    const customer = snapshot.rows.find(x => x.id === 'customer:check-1');
    assert.equal(customer.partyName, 'فروشگاه آریا');
    assert.equal(customer.invoiceNumber, '102');
    assert.equal(customer.dueDiff, 0);
    assert.equal(customer.status, 'pending');
    assert.equal(customer.amount, 5000000);
  });
  check('bridge snapshot preserves supplier bounced face value, not zero paid amount', () => {
    const snapshot = bridge.getChecksSnapshot();
    const bounced = snapshot.rows.find(x => x.id === 'supplier:sup-1:id:sup-check-1');
    assert.equal(bounced.amount, 7000000);
    assert.equal(bounced.status, 'bounced');
    assert.equal(bounced.statusLabel, 'برگشتی');
    assert.equal(bounced.bank, 'ملت');
  });
  check('bridge excludes non-check supplier payments', () => {
    const snapshot = bridge.getChecksSnapshot();
    assert.equal(snapshot.rows.filter(x => x.side === 'supplier').length, 2);
  });
  check('snapshot is read-only and does not mutate source data', () => {
    bridge.getChecksSnapshot();
    assert.equal(JSON.stringify(data), before);
  });
  check('customer status action delegates to the existing legacy control', () => {
    assert.equal(bridge.runCustomerCheckStatusToggle('check-1'), true);
    assert.equal(toggleClicks, 1);
    assert.equal(bridge.runCustomerCheckStatusToggle('missing'), false);
  });
  check('checks route activates the independent React ledger and hides the legacy page', () => {
    assert.match(appSource, /const useNewChecks = route === '\/checks'/);
    assert.match(appSource, /\|\| useNewChecks;/);
    assert.match(appSource, /<Checks snapshot=\{checksSnapshot\}/);
  });
  check('check detail route is a full-page React surface and preserves the selected side', () => {
    assert.match(appSource, /<CheckDetail snapshot=\{checksSnapshot\}/);
    assert.match(appSource, /onBack=\{\(\) => navigateHost\(`\/checks\?side=\$\{currentCheckSide\}`\)\}/);
    assert.match(appSource, /initialSide=\{currentCheckSide\}/);
  });
  check('segmented side selection keeps the legacy form and status controls on the same side', () => {
    const checksUi = fs.readFileSync(path.join(auditRoot, 'artifacts/bagheri-crm/src/Checks.tsx'), 'utf8');
    assert.match(checksUi, /onSideChange\(next\)/);
    assert.match(appSource, /onSideChange=\{\(side\) => navigateLegacy\(`\/checks\?side=\$\{side\}`\)\}/);
  });
  check('new check entry still invokes the official legacy FAB', () => {
    assert.match(appSource, /const openLegacyCheckCreator = useCallback/);
    assert.match(appSource, /fab\.click\(\)/);
    assert.match(appSource, /host-action-mode/);
  });
  check('customer check status still delegates to the original data-toggle-check control', () => {
    assert.match(bridgeSource, /querySelectorAll\('\[data-toggle-check\]'\)/);
    assert.match(bridgeSource, /buttons\[i\]\.click\(\)/);
  });
  check('new check surfaces contain no disclosure accordion markup or financial writes', () => {
    const checksUi = fs.readFileSync(path.join(auditRoot, 'artifacts/bagheri-crm/src/Checks.tsx'), 'utf8');
    const detailUi = fs.readFileSync(path.join(auditRoot, 'artifacts/bagheri-crm/src/CheckDetail.tsx'), 'utf8');
    assert.doesNotMatch(checksUi + detailUi, /<details|<summary|saveData\(|indexedDB|localStorage/);
  });

  process.stdout.write(`\n${passed} checks passed, 0 failed\n`);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
