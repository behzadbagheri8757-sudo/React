/* js/views/customers.js — SPA Customers list view (Phase 4).
   Extracted from customers.html. Reuses customerTotals/data.customers as-is.
   No new financial logic; behavior mirrors the MPA page 1:1.
*/
'use strict';

(function (global) {
  let custQuery = '';
  let custFilter = 'all'; // all | debt | settled | credit
  let custSortBy = 'name'; // name | debt | last_visit | priority
  let locFilter = { regionId: '', routeId: '', neighborhoodId: '', unassigned: false };

  let searchHandler = null;
  let sortHandler = null;
  let chipHandlers = [];
  let listClickHandler = null;
  let listKeyHandler = null;
  let locFilterHandler = null;
  let locUnassignedHandler = null;
  function customerHref(cid) {
    return '#/customer?id=' + encodeURIComponent(cid);
  }

  function navigateToCustomer(cid) {
    AppRouter.navigate('/customer', { id: cid });
  }

  /* Priority/story lookup — cached for the current view state and only
     recomputed when the underlying data actually changes (mount, or a
     ViewHost data-refresh), never on every keystroke/filter/sort click.
     Read-only use of the existing frozen Priority Engine; no new
     scoring, no new thresholds (see spec §9.6 performance rule). */
  let custPriorityMap = null;
  let custCtx = null;
  function buildPriorityLookup() {
    const map = Object.create(null);
    if (typeof calculateAllCustomerPriorities !== 'function') return map;
    let list = [];
    try { list = calculateAllCustomerPriorities(custCtx) || []; } catch (e) { return map; }
    list.forEach(function (p) { if (p && p.customerId) map[p.customerId] = p; });
    return map;
  }

  /* Presentation-only: compact 8-week customer purchase sparkline.
     The chart intentionally uses the same invoice-total basis as the
     customer detail trend: it is a visual shape of purchase activity,
     not a new accounting/Intelligence metric. */
  function customerSparklineHtml(cid, ctx) {
    try {
      const invs = (typeof customerInvoices === 'function' ? customerInvoices(cid, ctx) : []) || [];
      if (!invs.length) return '';
      const now = new Date(); now.setHours(0,0,0,0);
      const vals = new Array(8).fill(0);
      invs.forEach(function (inv) {
        if (!inv || !inv.date) return;
        const d = new Date(inv.date + 'T00:00:00'); if (isNaN(d.getTime())) return;
        d.setHours(0,0,0,0);
        const days = Math.floor((now - d) / 86400000);
        if (days < 0 || days >= 56) return;
        vals[7 - Math.floor(days / 7)] += Number(inv.total) || 0;
      });
      if (!vals.some(function (v) { return v > 0; })) return '';
      const max = Math.max.apply(null, vals) || 1;
      // Presentation only: «declining» = the last 4 weeks bought less than the 4 weeks before them.
      const prevSum = vals[0] + vals[1] + vals[2] + vals[3];
      const lastSum = vals[4] + vals[5] + vals[6] + vals[7];
      const trendCls = (prevSum > 0 && lastSum < prevSum) ? ' is-down' : '';
      const left = 5, right = 91;
      const pts = vals.map(function (v, i) {
        const x = left + i * ((right - left) / (vals.length - 1));
        const y = 18 - (v / max) * 13;
        return x.toFixed(1) + ',' + y.toFixed(1);
      }).join(' ');
      const last = pts.split(' ').pop();
      const lastParts = last.split(',');
      const dotLeftPct = parseFloat(lastParts[0]);
      const dotTopPct = (parseFloat(lastParts[1]) / 20) * 100;
      const sparkCoords = pts.split(' ').map(function (q) { return q.split(',').map(Number); });
      const sparkLine = chartSmoothPath(sparkCoords);
      const sparkArea = sparkLine + ' L ' + sparkCoords[sparkCoords.length - 1][0].toFixed(1) + ' 20 L ' + sparkCoords[0][0].toFixed(1) + ' 20 Z';
      const sparkId = 'cls-' + String(cid).replace(/[^a-zA-Z0-9_-]/g, '');
      return '<span class="customer-row-spark' + trendCls + '" aria-label="روند خرید، ۸ هفته اخیر"><svg viewBox="0 0 100 20" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="' + sparkId + '" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="100" y2="0"><stop class="ch-a" offset="0"/><stop class="ch-b" offset="1"/></linearGradient></defs><path class="ch-area" d="' + sparkArea + '"/><path class="ch-line" d="' + sparkLine + '" stroke="url(#' + sparkId + ')" vector-effect="non-scaling-stroke"/></svg><i class="customer-row-spark-dot" style="left:' + dotLeftPct + '%;top:' + dotTopPct + '%;"></i></span>';
    } catch (e) { return ''; }
  }

  function renderCustomerListOnly() {
    const listEl = document.getElementById('customer-list');
    if (!listEl) return;

    if (!custPriorityMap) custPriorityMap = buildPriorityLookup();
    const priorityMap = custPriorityMap;
    let rows = (data.customers || []).slice();
    const q = (custQuery || '').trim().toLowerCase();
    if (q) {
      rows = rows.filter(function (c) {
        return (
          (c.name || '').toLowerCase().includes(q) ||
          (c.phone || '').includes(q) ||
          (c.region || '').toLowerCase().includes(q) ||
          (c.ownerName || '').toLowerCase().includes(q) ||
          (c.address || '').toLowerCase().includes(q)
        );
      });
    }

    rows = rows.map(function (c) {
      return { c: c, t: customerTotals(c.id, custCtx) };
    });

    if (custFilter === 'debt') rows = rows.filter(function (x) { return x.t.balance > 0; });
    else if (custFilter === 'settled') rows = rows.filter(function (x) { return x.t.balance === 0; });
    else if (custFilter === 'credit') rows = rows.filter(function (x) { return x.t.balance < 0; });

    if (locFilter.unassigned) {
      rows = rows.filter(function (x) { return !x.c.locationId; });
    } else if (locFilter.neighborhoodId) {
      rows = rows.filter(function (x) { return x.c.locationId === locFilter.neighborhoodId; });
    } else if (locFilter.routeId) {
      const neighIds = listNeighborhoods(locFilter.routeId).map(function (n) { return n.id; });
      rows = rows.filter(function (x) { return x.c.locationId === locFilter.routeId || (x.c.locationId && neighIds.indexOf(x.c.locationId) !== -1); });
    } else if (locFilter.regionId) {
      const routeIds = listRoutes(locFilter.regionId).map(function (r) { return r.id; });
      let neighIds = [];
      routeIds.forEach(function (rid) { neighIds = neighIds.concat(listNeighborhoods(rid).map(function (n) { return n.id; })); });
      rows = rows.filter(function (x) { return x.c.locationId && (routeIds.indexOf(x.c.locationId) !== -1 || neighIds.indexOf(x.c.locationId) !== -1); });
    }

    function lastVisitTime(c) {
      const visits = Array.isArray(c.visits) ? c.visits : [];
      if (!visits.length) return 0;
      const v = visits.slice().sort(function (a, b) {
        return (b.date || '').localeCompare(a.date || '') || (b.time || '').localeCompare(a.time || '');
      })[0];
      const d = v && v.date ? new Date(v.date + (v.time ? 'T' + v.time : 'T00:00:00')).getTime() : 0;
      return Number.isFinite(d) ? d : 0;
    }
    if (custSortBy === 'debt') {
      rows.sort(function (a, b) { return b.t.balance - a.t.balance || (a.c.name || '').localeCompare(b.c.name || '', 'fa'); });
    } else if (custSortBy === 'last_visit') {
      rows.sort(function (a, b) { return lastVisitTime(b.c) - lastVisitTime(a.c) || (a.c.name || '').localeCompare(b.c.name || '', 'fa'); });
    } else if (custSortBy === 'priority') {
      rows.sort(function (a, b) {
        const ap = priorityMap[a.c.id] ? Number(priorityMap[a.c.id].priorityScore) || 0 : 0;
        const bp = priorityMap[b.c.id] ? Number(priorityMap[b.c.id].priorityScore) || 0 : 0;
        return bp - ap || (a.c.name || '').localeCompare(b.c.name || '', 'fa');
      });
    } else {
      rows.sort(function (a, b) { return (a.c.name || '').localeCompare(b.c.name || '', 'fa'); });
    }

    // Presentation only: result count under the filters (reads the already-computed rows).
    const countEl = document.getElementById('customer-count');
    if (countEl) countEl.textContent = rows.length ? enToFaDigits(String(rows.length)) + ' مشتری' : '';

    if (!rows.length) {
      listEl.innerHTML =
        '<div class="empty">' +
        ((data.customers || []).length
          ? 'موردی با این فیلتر پیدا نشد'
          : 'هنوز مشتری ثبت نشده است. با دکمه + مشتری جدید اضافه کنید.') +
        '</div>';
      return;
    }

    listEl.innerHTML = rows
      .map(function (x) {
        const c = x.c;
        const t = x.t;
        const word = balanceStatusWord(t.balance);
        const color = t.balance > 0 ? 'accent-rust' : t.balance < 0 ? 'accent-olive' : 'accent-olive';

        // One compact status badge + one activity metric. These are read-only
        // presentations of existing frozen outputs; no new scoring/thresholds.
        const pr = priorityMap[c.id] || null;
        const riskLevel = pr ? pr.riskLevel : null;
        const riskCls = riskLevel ? 'radar-risk-' + riskLevel : '';
        const behavior = (typeof customerBehavior === 'function')
          ? (function(){ try { return customerBehavior(c.id, custCtx) || {}; } catch(e){ return {}; } })()
          : {};
        const watchCount = (typeof getActiveWatchOccurrences === 'function')
          ? (function(){ try { return (getActiveWatchOccurrences(c.id) || []).length; } catch(e){ return 0; } })()
          : 0;
        const status = (typeof customerStatus === 'function') ? customerStatus(c.id, custCtx) : null;

        let badgeLabel = '';
        let badgeTone = 'neutral';
        if (c.active === false) { badgeLabel = 'غیرفعال شده'; badgeTone = 'muted'; }
        else if (c.oneOff) { badgeLabel = 'یک‌بار‌مصرف'; badgeTone = 'muted'; }
        else if ((riskLevel === 'critical' || riskLevel === 'high') && typeof getRiskBadge === 'function') {
          // Intentional: the list badges ONLY critical/high (medium/low stay badge-less so the list
          // stays scannable). Detail and Quick View show the full label via the same getRiskBadge.
          var _lr = getRiskBadge(riskLevel);
          badgeLabel = _lr.label;
          badgeTone = _lr.tone;
        }
        else if (behavior.behindPattern === true) { badgeLabel = 'عقب‌افتاده'; badgeTone = 'warning'; }
        else if (status === 'lost') { badgeLabel = 'از دست رفته'; badgeTone = 'muted'; }
        else if (status === 'inactive') { badgeLabel = 'سرد شده'; badgeTone = 'muted'; }
        else if (status === 'new') { badgeLabel = 'جدید'; badgeTone = 'neutral'; }

        const days = (typeof customerStats === 'function')
        ? (function(){ try { return customerStats(c.id, custCtx).daysSinceLast; } catch(e){ return Infinity; } })()
          : Infinity;
        const daysText = Number.isFinite(days)
          ? ('آخرین خرید: ' + Math.max(0, Math.round(days)) + ' روز پیش')
          : 'هنوز خریدی ثبت نشده';
        const watchTitle = watchCount > 0 ? 'هشدار فعال: ' + watchCount + ' مورد' : '';

        return (
          '<a class="ledger-row customer-list-row ' + riskCls + '" data-open-customer="' +
          esc(c.id) +
          '" href="' +
          customerHref(c.id) +
          '" style="text-decoration:none;color:inherit;"' +
          (watchTitle ? ' title="' + esc(watchTitle) + '"' : '') + '>' +
          '<span class="customer-row-main">' +
          '<span class="customer-row-title-line">' +
          '<span class="customer-row-name tx-row-title">' + esc(c.name) + '</span>' +
          customerSparklineHtml(c.id, custCtx) +
          '</span>' +
          '<span class="customer-row-meta-line">' +
          (badgeLabel
            ? '<span class="customer-row-status badge tone-' + badgeTone + '">' + esc(badgeLabel) + '</span>'
            : '') +
          '<span class="customer-row-meta">' + esc(daysText) + '</span>' +
          (watchCount > 0
            ? '<span class="customer-row-watch" aria-label="هشدار فعال" title="' + esc(watchTitle) + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path></svg></span>'
            : '') +
          '</span>' +
          '</span>' +
          '<span class="customer-row-balance ' + color + '">' +
          '<span class="customer-row-balance-label">' + esc(word) + '</span>' +
          '<span class="customer-row-balance-value">' +
          (t.balance !== 0 ? toman(Math.abs(t.balance)) + ' ت' : '') +
          '</span>' +
          '</span>' +
          '<span role="button" tabindex="0" class="customer-row-detail-hitarea" data-customer-detail="' + esc(c.id) + '" aria-label="مشاهده جزئیات مشتری" title="مشاهده جزئیات مشتری"></span>' +
          '</a>'
        );
      })
      .join('');
  }

  function renderLocationFilterSheet() {
    const regions = listRegions();
    const routes = locFilter.regionId ? listRoutes(locFilter.regionId) : (data.routes || []).slice().sort((a,b)=>(a.name||'').localeCompare(b.name||'','fa'));
    const neighs = locFilter.routeId ? listNeighborhoods(locFilter.routeId) : [];
    const opt = function (list, selId, allLabel) {
      return '<option value="">' + allLabel + '</option>' + list.map(function (x) {
        return '<option value="' + esc(x.id) + '" ' + (x.id === selId ? 'selected' : '') + '>' + esc(x.name) + '</option>';
      }).join('');
    };
    openSheet(
      '<h3>فیلتر مشتریان</h3>' +
      '<div class="field"><label>مسیر</label><select id="customer-filter-route">' + opt(routes, locFilter.routeId, 'همه مسیرها') + '</select></div>' +
      '<div class="field"><label>منطقه</label><select id="customer-filter-region">' + opt(regions, locFilter.regionId, 'همه مناطق') + '</select></div>' +
      '<div class="field"><label>محله</label><select id="customer-filter-neigh" ' + (!locFilter.routeId ? 'disabled' : '') + '>' + opt(neighs, locFilter.neighborhoodId, 'همه محله‌ها') + '</select></div>' +
      '<div class="btn-row" style="margin-top:4px;"><button type="button" class="btn small secondary" id="customer-filter-clear">پاک کردن فیلتر</button></div>'
    );

    const routeSel = document.getElementById('customer-filter-route');
    const regionSel = document.getElementById('customer-filter-region');
    const neighSel = document.getElementById('customer-filter-neigh');
    const clearBtn = document.getElementById('customer-filter-clear');

    function refreshSheet(keepOpen) {
      if (!keepOpen) return;
      renderLocationFilterSheet();
    }
    if (routeSel) routeSel.addEventListener('change', function () {
      locFilter.routeId = routeSel.value;
      locFilter.neighborhoodId = '';
      locFilter.unassigned = false;
      if (locFilter.routeId) {
        const r = getRoute(locFilter.routeId);
        locFilter.regionId = r ? r.regionId : '';
      }
      renderCustomerListOnly();
      refreshSheet(true);
    });
    if (regionSel) regionSel.addEventListener('change', function () {
      locFilter.regionId = regionSel.value;
      if (locFilter.routeId) {
        const r = getRoute(locFilter.routeId);
        if (!r || r.regionId !== locFilter.regionId) locFilter.routeId = '';
      }
      locFilter.neighborhoodId = '';
      locFilter.unassigned = false;
      renderCustomerListOnly();
      refreshSheet(true);
    });
    if (neighSel) neighSel.addEventListener('change', function () {
      locFilter.neighborhoodId = neighSel.value;
      locFilter.unassigned = false;
      renderCustomerListOnly();
    });
    if (clearBtn) clearBtn.addEventListener('click', function () {
      locFilter = { regionId:'', routeId:'', neighborhoodId:'', unassigned:false };
      renderCustomerListOnly();
      closeModal();
      updateLocationFilterIndicator();
    });
  }

  function updateLocationFilterIndicator() {
    const el = document.getElementById('customer-filter-indicator');
    const btn = document.getElementById('customer-filter');
    if (!el || !btn) return;
    const count = (locFilter.regionId ? 1 : 0) + (locFilter.routeId ? 1 : 0) + (locFilter.neighborhoodId ? 1 : 0) + (locFilter.unassigned ? 1 : 0);
    el.innerHTML = count
      ? '<span>فیلتر: ' + esc(getLocationDisplayString(locFilter.neighborhoodId || locFilter.routeId || locFilter.regionId)) + '</span><button type="button" class="chip" id="customer-filter-clear-inline">×</button>'
      : '';
    btn.classList.toggle('active', count > 0);
    const clear = document.getElementById('customer-filter-clear-inline');
    if (clear) clear.onclick = function () {
      locFilter = { regionId:'', routeId:'', neighborhoodId:'', unassigned:false };
      updateLocationFilterIndicator();
      renderCustomerListOnly();
    };
  }

  function drawCustomersPage(root) {
    const chip = function (id, label) {
      return '<button type="button" class="chip ' + (custFilter === id ? 'active' : '') + '" data-filter="' + id + '">' + label + '</button>';
    };
    root.innerHTML =
      '<div class="field"><input id="customer-search" placeholder="جستجوی نام، آدرس، تلفن، منطقه و…" value="' + esc(custQuery) + '" autocomplete="off"></div>' +
      '<div class="chip-row" id="customer-chips">' + chip('all','همه') + chip('debt','بدهکار') + chip('settled','تسویه') + chip('credit','بستانکار') + '</div>' +
      '<div class="bp-customer-secondary-filters">' +
      '<div class="btn-row cl-tools">' +
      '<button type="button" class="btn small secondary" id="customer-filter">فیلتر منطقه</button>' +
      '<label class="bp-sort-label" for="customer-sort">مرتب‌سازی</label>' +
      '<select class="tx-toolbar-select" id="customer-sort">' +
      '<option value="priority" ' + (custSortBy === 'priority' ? 'selected' : '') + '>اولویت</option>' +
      '<option value="last_visit" ' + (custSortBy === 'last_visit' ? 'selected' : '') + '>آخرین ویزیت</option>' +
      '<option value="debt" ' + (custSortBy === 'debt' ? 'selected' : '') + '>بدهی</option>' +
      '<option value="name" ' + (custSortBy === 'name' ? 'selected' : '') + '>نام</option>' +
      '</select>' +
      '</div>' +
      '</div>' +
      '<div id="customer-filter-indicator" class="customer-filter-indicator" aria-live="polite"></div>' +
      '<div id="customer-count" class="cl-count" aria-live="polite"></div>' +
      '<div class="customer-list-trend-hint"><span class="customer-list-trend-sample"><i></i><b></b></span><span>روند خرید · ۸ هفته اخیر</span></div>' +
      '<div id="customer-list"></div>';

    const searchEl = document.getElementById('customer-search');
    searchHandler = function (e) { custQuery = e.target.value; renderCustomerListOnly(); };
    searchEl.addEventListener('input', searchHandler);

    chipHandlers = [];
    document.querySelectorAll('#customer-chips [data-filter]').forEach(function (btn) {
      const fn = function () {
        custFilter = btn.getAttribute('data-filter');
        document.querySelectorAll('#customer-chips [data-filter]').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-filter') === custFilter); });
        renderCustomerListOnly();
      };
      btn.addEventListener('click', fn); chipHandlers.push({el:btn, fn:fn});
    });

    const filterBtn = document.getElementById('customer-filter');
    filterBtn.addEventListener('click', renderLocationFilterSheet);

    const sortEl = document.getElementById('customer-sort');
    sortHandler = function (e) { custSortBy = e.target.value; renderCustomerListOnly(); };
    if (sortEl) sortEl.addEventListener('change', sortHandler);

    const list = document.getElementById('customer-list');
    listClickHandler = function (e) {
      const detailButton = e.target.closest('[data-customer-detail]');
      if (detailButton) {
        e.preventDefault();
        e.stopPropagation();
        navigateToCustomer(detailButton.getAttribute('data-customer-detail'));
        return;
      }
      const row = e.target.closest('[data-open-customer]');
      if (!row) return;
      if (typeof isSpaShell === 'function' && isSpaShell()) {
        e.preventDefault();
        if (typeof openCustomerQuickView === 'function') openCustomerQuickView(row.getAttribute('data-open-customer'));
      }
    };
    list.addEventListener('click', listClickHandler);
    /* keyboard / VoiceOver activation for the span[role=button] hit-area (a <button> may not live inside the row's <a>) */
    listKeyHandler = function (e) {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const hit = e.target.closest && e.target.closest('[data-customer-detail]');
      if (!hit) return;
      e.preventDefault();
      e.stopPropagation();
      navigateToCustomer(hit.getAttribute('data-customer-detail'));
    };
    list.addEventListener('keydown', listKeyHandler);
    updateLocationFilterIndicator();
    renderCustomerListOnly();
  }

  function mount(root, params) {
    let refreshToken = null;
    if (!root) return function () {};
    const fab = document.getElementById('fab');
    if (fab) {
      fab.style.display = 'block';
      fab.onclick = function () {
        if (typeof openAddCustomer === 'function') openAddCustomer();
      };
    }
    const nav = document.getElementById('nav');
    if (nav) nav.style.display = '';

    custQuery = '';
    custFilter = (params && ['debt', 'settled', 'credit'].indexOf(params.filter) !== -1) ? params.filter : 'all';
    custSortBy = 'priority';
    locFilter = { regionId: '', routeId: '', neighborhoodId: '', unassigned: false };
    custCtx = typeof createComputationContext === 'function'
      ? createComputationContext({ data: data })
      : null;
    custPriorityMap = null; // fresh on entering the page
    drawCustomersPage(root);

    // A real data refresh (invoice/payment/visit recorded elsewhere) can
    // change risk/story output — invalidate the cache then, not on every
    // keystroke render.
    refreshToken = ViewHost.setRefresh(function () {
      custCtx = typeof createComputationContext === 'function'
        ? createComputationContext({ data: data })
        : null;
      custPriorityMap = null;
      renderCustomerListOnly();
    });

    // openAddCustomer/openAddTransaction/etc. call render() after save — bind to list-only refresh.
    return function unmount() {
      ViewHost.clearRefresh(refreshToken);
      refreshToken = null;
      custCtx = null;
      if (searchHandler) {
        const se = document.getElementById('customer-search');
        if (se) se.removeEventListener('input', searchHandler);
      }
      searchHandler = null;

      chipHandlers.forEach(function (h) {
        try {
          h.el.removeEventListener('click', h.fn);
        } catch (e) {}
      });
      chipHandlers = [];

      if (sortHandler) {
        const sb = document.getElementById('customer-sort');
        if (sb) sb.removeEventListener('change', sortHandler);
      }
      sortHandler = null;

      if (listClickHandler) {
        const list = document.getElementById('customer-list');
        if (list) list.removeEventListener('click', listClickHandler);
        if (list && listKeyHandler) list.removeEventListener('keydown', listKeyHandler);
      }
      listClickHandler = null;
      listKeyHandler = null;

      if (fab) {
        fab.style.display = 'none';
        fab.onclick = null;
      }
      root.innerHTML = '';
    };
  }

  global.CustomersView = { mount: mount, unmount: function () {} };
})(typeof window !== 'undefined' ? window : this);
