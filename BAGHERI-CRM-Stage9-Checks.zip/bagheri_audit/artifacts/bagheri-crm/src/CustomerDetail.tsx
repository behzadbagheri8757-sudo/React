import { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Banknote,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ClipboardList,
  FileText,
  MapPin,
  Package,
  Phone,
  ReceiptText,
  UserRound,
  Wallet,
} from 'lucide-react';

export type CustomerDetailSnapshot = {
  found: boolean;
  customerId: string;
  customer?: {
    id: string;
    name: string;
    phone: string;
    ownerName: string;
    region: string;
    route: string;
    address: string;
    note: string;
    active: boolean;
    oneOff: boolean;
    status: string;
    location: string;
  };
  financial?: {
    balance: number;
    invTotal: number;
    payTotal: number;
    checkTotal: number;
    openingBalance: number;
    profit: number;
    invoiceCount: number;
    paymentCount: number;
    checkCount: number;
  };
  purchase?: {
    lastPurchase: { date: string; amount: number; invoiceNumber: string; daysSince: number | null } | null;
    timing: { state: string; text: string } | null;
    suggestedProducts: Array<{ productId: string; name: string; reasonText: string; lastPurchaseText: string }>;
    productsToCheck: Array<{ productId: string; name: string; kind: string; detail: string }>;
  };
  priority?: {
    riskLevel: string;
    healthLabel: string;
    story: string;
    action: { actionType: string; action: string; reason: string; urgency: string } | null;
  };
  alert?: { level: string; kind: string; text: string } | null;
  watches?: Array<{ id: string; product: string; reason: string; severity: string }>;
  followUps?: Array<{ id: string; product: string; text: string; note: string }>;
  invoices?: Array<{ id: string; number: string; date: string; total: number; status: string }>;
  payments?: Array<{ id: string; date: string; amount: number; method: string; note: string; invoiceId: string }>;
  checks?: Array<{ id: string; number: string; dueDate: string; amount: number; status: string; invoiceId: string }>;
  visits?: Array<{ id: string; date: string; time: string; result: string; score: number | null; ordered: boolean; nextAction: string; note: string; offeredProducts: string[] }>;
  behavior?: {
    behindPattern: boolean | null;
    daysSinceLast: number | null;
    avgIntervalDays: number | null;
    amountTrend: string;
    topProducts: string[];
    decliningProducts: string[];
    consecutiveNoOrder: number;
    conversionRate: number | null;
    visitCount: number;
    lastNextAction: string;
    purchaseDayCount: number;
  };
  lastVisitDate: string;
  updatedAt: number;
};

type DetailSection = 'invoices' | 'payments' | 'checks' | 'visits' | 'behavior' | 'watches';
type ActionName = 'invoice' | 'payment' | 'visit' | 'check' | 'edit' | 'statement';

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const money = (value: number) => `${fa(value)} تومان`;
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return money(amount);
};

function balanceText(balance: number) {
  if (balance > 0) return 'بدهکار';
  if (balance < 0) return 'بستانکار';
  return 'تسویه';
}

function statusText(status: string) {
  if (status === 'active') return 'فعال';
  if (status === 'inactive') return 'سرد شده';
  if (status === 'lost') return 'از دست رفته';
  if (status === 'new') return 'بدون خرید';
  return status || 'نامشخص';
}

function DetailRow({ icon: Icon, title, meta, value, onClick }: {
  icon: typeof FileText;
  title: string;
  meta?: string;
  value?: string;
  onClick?: () => void;
}) {
  const content = <>
    <span className="cd-row-icon"><Icon size={17} /></span>
    <span className="cd-row-copy"><strong>{title}</strong>{meta && <small>{meta}</small>}</span>
    {value && <b className="cd-row-value">{value}</b>}
    <ChevronLeft className="cd-row-chevron" size={17} />
  </>;
  return onClick ? <button className="cd-nav-row" type="button" onClick={onClick}>{content}</button> : <div className="cd-nav-row is-static">{content}</div>;
}

export default function CustomerDetail({ snapshot, onAction, onNavigate, onBackToCustomers }: {
  snapshot: CustomerDetailSnapshot | null;
  onAction: (action: ActionName, customerId: string) => void;
  onNavigate: (path: string) => void;
  onBackToCustomers: () => void;
}) {
  const [section, setSection] = useState<DetailSection | null>(null);

  if (!snapshot) {
    return <div className="customer-detail-page" dir="rtl"><div className="customers-loading"><span className="nd-spinner"/> در حال دریافت پرونده مشتری…</div></div>;
  }
  if (!snapshot.found || !snapshot.customer || !snapshot.financial) {
    return <div className="customer-detail-page" dir="rtl"><div className="cd-not-found"><strong>پرونده مشتری پیدا نشد</strong><p>ممکن است شناسه مشتری معتبر نباشد یا اطلاعات هنوز بارگذاری نشده باشد.</p><button type="button" onClick={onBackToCustomers}>بازگشت به مشتریان</button></div></div>;
  }

  const customer = snapshot.customer;
  const financial = snapshot.financial;
  const purchase = snapshot.purchase;
  const priority = snapshot.priority;
  const watches = snapshot.watches ?? [];
  const followUps = snapshot.followUps ?? [];
  const invoices = snapshot.invoices ?? [];
  const payments = snapshot.payments ?? [];
  const checks = snapshot.checks ?? [];
  const visits = snapshot.visits ?? [];
  const behavior = snapshot.behavior;
  const initial = customer.name.trim().slice(0, 1) || 'م';

  if (section) {
    const titles: Record<DetailSection, string> = {
      invoices: 'فاکتورهای مشتری',
      payments: 'دریافت‌ها و برگشت‌ها',
      checks: 'چک‌های مشتری',
      visits: 'سوابق ویزیت',
      behavior: 'رفتار خرید',
      watches: 'هشدارها و پیگیری‌ها',
    };
    return <div className="customer-detail-page" dir="rtl">
      <div className="cd-section-page-head">
        <button type="button" onClick={() => setSection(null)} aria-label="بازگشت به پرونده مشتری"><ArrowRight size={19}/></button>
        <div><small>{customer.name}</small><h1>{titles[section]}</h1></div>
      </div>

      {section === 'invoices' && <div className="cd-history-list">
        {invoices.length ? invoices.map((invoice) => <button type="button" className="cd-history-row" key={invoice.id} onClick={() => onNavigate(`/invoice?id=${encodeURIComponent(invoice.id)}&fromCustomer=${encodeURIComponent(customer.id)}&fromSection=invoices`)}>
          <span className="cd-history-icon"><ReceiptText size={17}/></span><span className="cd-history-copy"><strong>فاکتور {invoice.number ? `شماره ${invoice.number}` : ''}</strong><small>{invoice.date} · {invoice.status}</small></span><b>{compact(invoice.total)}</b><ChevronLeft size={16}/>
        </button>) : <div className="cd-empty">برای این مشتری فاکتوری ثبت نشده است.</div>}
      </div>}

      {section === 'payments' && <div className="cd-history-list">
        {payments.length ? payments.map((payment) => <div className="cd-history-row is-static" key={payment.id}>
          <span className="cd-history-icon"><Wallet size={17}/></span><span className="cd-history-copy"><strong>{payment.method}</strong><small>{payment.date}{payment.note ? ` · ${payment.note}` : ''}</small></span><b>{compact(payment.amount)}</b>
        </div>) : <div className="cd-empty">دریافتی یا برگشتی ثبت نشده است.</div>}
      </div>}

      {section === 'checks' && <div className="cd-history-list">
        {checks.length ? checks.map((check) => <div className="cd-history-row is-static" key={check.id}>
          <span className="cd-history-icon"><Banknote size={17}/></span><span className="cd-history-copy"><strong>{check.number || 'چک'}</strong><small>سررسید: {check.dueDate} · {check.status}</small></span><b>{compact(check.amount)}</b>
        </div>) : <div className="cd-empty">چکی برای این مشتری ثبت نشده است.</div>}
      </div>}

      {section === 'visits' && <div className="cd-history-list">
        {visits.length ? visits.map((visit) => <div className="cd-visit-card" key={visit.id}>
          <div className="cd-visit-head"><strong>{visit.result || 'ویزیت'}</strong><span>{visit.date}{visit.time ? ` · ${visit.time}` : ''}</span></div>
          {visit.score !== null && <small>امتیاز ارزیابی: {fa(visit.score)} از ۱۰۰</small>}
          {visit.offeredProducts.length > 0 && <p>پیشنهاد کالا: {visit.offeredProducts.join('، ')}</p>}
          {visit.nextAction && <p>اقدام بعدی: {visit.nextAction}</p>}
          {visit.note && <p>{visit.note}</p>}
          <span className={`cd-visit-result${visit.ordered ? ' is-ordered' : ''}`}>{visit.ordered ? 'سفارش ثبت شد' : 'بدون سفارش'}</span>
        </div>) : <div className="cd-empty">هنوز ویزیتی ثبت نشده است.</div>}
      </div>}

      {section === 'behavior' && <div className="cd-section-stack">
        <div className="cd-behavior-summary">
          <span>وضعیت رفتار خرید</span>
          <strong>{behavior?.behindPattern === true ? 'از موعد معمول خرید عقب افتاده' : behavior?.behindPattern === false ? 'در محدوده الگوی معمول خرید' : 'سابقه کافی برای تشخیص الگو نیست'}</strong>
          {behavior?.daysSinceLast !== null && behavior?.daysSinceLast !== undefined && <small>{fa(behavior.daysSinceLast)} روز از آخرین خرید گذشته است.</small>}
          {behavior?.avgIntervalDays !== null && behavior?.avgIntervalDays !== undefined && <small>فاصله معمول خرید: حدود {fa(behavior.avgIntervalDays)} روز</small>}
        </div>
        {behavior?.amountTrend && <div className="cd-info-line"><span>روند مبلغ خرید</span><strong>{behavior.amountTrend === 'up' ? 'افزایشی' : behavior.amountTrend === 'down' ? 'کاهشی' : 'تقریباً ثابت'}</strong></div>}
        {behavior?.topProducts.length ? <div className="cd-info-group"><strong>کالاهای اصلی مشتری</strong><p>{behavior.topProducts.join('، ')}</p></div> : null}
        {behavior?.decliningProducts.length ? <div className="cd-info-group"><strong>کالاهای دارای افت خرید</strong><p>{behavior.decliningProducts.join('، ')}</p></div> : null}
        {behavior?.consecutiveNoOrder ? <div className="cd-info-line"><span>ویزیت‌های پیاپی بدون سفارش</span><strong>{fa(behavior.consecutiveNoOrder)}</strong></div> : null}
        {behavior?.conversionRate !== null && behavior?.conversionRate !== undefined && <div className="cd-info-line"><span>تبدیل ویزیت به سفارش</span><strong>{fa(Math.round(behavior.conversionRate * 100))}٪</strong></div>}
        {behavior?.lastNextAction && <div className="cd-info-group"><strong>اقدام ثبت‌شده در ویزیت قبل</strong><p>{behavior.lastNextAction}</p></div>}
      </div>}

      {section === 'watches' && <div className="cd-section-stack">
        {snapshot.alert && <div className={`cd-alert is-${snapshot.alert.level}`}><AlertTriangle size={18}/><div><strong>{snapshot.alert.text}</strong><small>بر اساس وضعیت ثبت‌شده در سامانه</small></div></div>}
        {watches.map((watch) => <div className="cd-watch-card" key={watch.id}><strong>{watch.product}</strong><p>{watch.reason}</p><small>شدت: {watch.severity}</small></div>)}
        {followUps.map((followUp) => <div className="cd-followup-card" key={followUp.id}><strong>{followUp.product || 'موضوع پیگیری'}</strong><p>{followUp.text}</p>{followUp.note && <small>{followUp.note}</small>}</div>)}
        {!watches.length && !followUps.length && !snapshot.alert && <div className="cd-empty">هشدار یا پیگیری بازی برای این مشتری ثبت نشده است.</div>}
      </div>}
    </div>;
  }

  return (
    <div className="customer-detail-page" dir="rtl">
      <div className="cd-customer-hero">
        <div className="cd-customer-avatar">{initial}</div>
        <div className="cd-customer-identity">
          <span className="cd-eyebrow">پرونده مشتری</span>
          <h1>{customer.name}</h1>
          <div className="cd-identity-meta">
            {customer.ownerName && <span><UserRound size={13}/>{customer.ownerName}</span>}
            {(customer.region || customer.route) && <span><MapPin size={13}/>{[customer.region, customer.route].filter(Boolean).join(' · ')}</span>}
            <span className={`cd-status${customer.active ? ' is-active' : ' is-muted'}`}>{customer.active ? (customer.oneOff ? 'یک‌بارمصرف' : statusText(priority?.healthLabel || customer.status)) : 'غیرفعال'}</span>
          </div>
        </div>
      </div>

      <section className={`cd-balance-panel${financial.balance > 0 ? ' is-debt' : financial.balance < 0 ? ' is-credit' : ''}`}>
        <div><span>مانده حساب</span><small>{balanceText(financial.balance)}</small></div>
        <strong>{compact(Math.abs(financial.balance))}</strong>
        <div className="cd-balance-foot"><span>مجموع خرید: {compact(financial.invTotal)}</span><span>پرداخت و چک: {compact(financial.payTotal + financial.checkTotal)}</span></div>
      </section>

      {snapshot.alert && <section className={`cd-alert is-${snapshot.alert.level}`}><AlertTriangle size={18}/><div><strong>{snapshot.alert.text}</strong><small>این هشدار از محاسبات و وضعیت ثبت‌شده فعلی خوانده شده است.</small></div></section>}

      {priority?.story && <section className={`cd-story-card is-${priority.riskLevel || 'normal'}`}><span>خلاصه وضعیت</span><p>{priority.story}</p></section>}

      <section className="cd-primary-actions" aria-label="اقدام‌های اصلی">
        <button type="button" onClick={() => onAction('invoice', customer.id)}><ReceiptText size={18}/><strong>ثبت فاکتور</strong></button>
        <button type="button" onClick={() => onAction('payment', customer.id)}><Wallet size={18}/><strong>ثبت دریافت</strong></button>
        <button type="button" onClick={() => onAction('visit', customer.id)}><CalendarDays size={18}/><strong>ثبت ویزیت</strong></button>
      </section>

      <section className="cd-previsit-section">
        <div className="cd-section-title"><div><span>آماده‌سازی ویزیت</span><small>اطلاعاتی که پیش از پیشنهاد کالا لازم است</small></div></div>
        <div className="cd-purchase-glance">
          <div><span>آخرین خرید</span><strong>{purchase?.lastPurchase ? compact(purchase.lastPurchase.amount) : 'ثبت نشده'}</strong><small>{purchase?.lastPurchase ? `${purchase.lastPurchase.date}${purchase.lastPurchase.invoiceNumber ? ` · فاکتور ${purchase.lastPurchase.invoiceNumber}` : ''}` : 'هنوز خریدی ثبت نشده است'}</small></div>
          {purchase?.timing && <div className={`cd-purchase-timing is-${purchase.timing.state}`}><span>زمان خرید بعدی</span><strong>{purchase.timing.text}</strong></div>}
        </div>
        {purchase?.suggestedProducts.length ? <div className="cd-product-group"><strong><Package size={15}/> پیشنهادهای محتمل</strong>{purchase.suggestedProducts.map((product) => <div className="cd-product-line" key={product.productId}><b>{product.name}</b><small>{product.reasonText}{product.lastPurchaseText ? ` · ${product.lastPurchaseText}` : ''}</small></div>)}</div> : null}
        {purchase?.productsToCheck.length ? <div className="cd-product-group is-check"><strong><AlertTriangle size={15}/> قبل از پیشنهاد بررسی کن</strong>{purchase.productsToCheck.map((product) => <div className="cd-product-line" key={product.productId}><b>{product.name}{product.kind === 'deferred' ? ' · موکول‌شده' : ''}</b><small>{product.detail}</small></div>)}</div> : null}
        {!purchase?.suggestedProducts.length && !purchase?.productsToCheck.length && <div className="cd-no-product-note"><CheckCircle2 size={16}/> در حال حاضر پیشنهاد یا مورد حل‌نشده‌ای برای نمایش وجود ندارد.</div>}
      </section>

      {priority?.action?.action && <section className="cd-recommended-action"><span>اقدام پیشنهادی</span><strong>{priority.action.action}</strong>{priority.action.reason && <small>{priority.action.reason}</small>}</section>}

      <section className="cd-financial-section">
        <div className="cd-section-title"><div><span>خلاصه مالی</span><small>خروجی محاسبات فعلی برنامه</small></div></div>
        <div className="cd-financial-grid">
          <div><small>مجموع خرید</small><strong>{compact(financial.invTotal)}</strong></div>
          <div><small>مجموع پرداخت</small><strong>{compact(financial.payTotal)}</strong></div>
          <div><small>مجموع چک</small><strong>{compact(financial.checkTotal)}</strong></div>
          <div><small>مانده اولیه</small><strong>{compact(financial.openingBalance)}</strong></div>
          <div><small>سود مشتری</small><strong>{compact(financial.profit)}</strong></div>
          <div><small>تعداد فاکتور</small><strong>{fa(financial.invoiceCount)}</strong></div>
        </div>
      </section>

      <section className="cd-history-section">
        <div className="cd-section-title"><div><span>سوابق مشتری</span><small>هر بخش در صفحه مستقل باز می‌شود</small></div></div>
        <div className="cd-nav-list">
          <DetailRow icon={ReceiptText} title="فاکتورها" meta="مشاهده ریز خریدها" value={fa(invoices.length)} onClick={() => setSection('invoices')}/>
          <DetailRow icon={Wallet} title="دریافت‌ها و برگشت‌ها" meta="گردش پرداخت مشتری" value={fa(payments.length)} onClick={() => setSection('payments')}/>
          <DetailRow icon={Banknote} title="چک‌ها" meta="وضعیت و سررسید" value={fa(checks.length)} onClick={() => setSection('checks')}/>
          <DetailRow icon={CalendarDays} title="ویزیت‌ها" meta="نتیجه و اقدام بعدی" value={fa(visits.length)} onClick={() => setSection('visits')}/>
          <DetailRow icon={Package} title="رفتار خرید" meta="الگوی خرید و کالاهای اصلی" onClick={() => setSection('behavior')}/>
          <DetailRow icon={AlertTriangle} title="هشدارها و پیگیری‌ها" meta="موارد فعال و نیازمند بررسی" value={fa(watches.length + followUps.length)} onClick={() => setSection('watches')}/>
        </div>
      </section>

      <section className="cd-contact-section">
        <div className="cd-section-title"><div><span>اطلاعات تماس و فروشگاه</span></div></div>
        {customer.phone && <a className="cd-contact-row" href={`tel:${customer.phone}`}><Phone size={16}/><span>{customer.phone}</span><small>تماس</small></a>}
        {customer.location && <div className="cd-contact-row"><MapPin size={16}/><span>{customer.location}</span></div>}
        {customer.address && <div className="cd-contact-row"><MapPin size={16}/><span>{customer.address}</span></div>}
        {customer.note && <div className="cd-customer-note"><ClipboardList size={15}/><span>{customer.note}</span></div>}
      </section>

      <section className="cd-secondary-actions">
        <button type="button" onClick={() => onAction('check', customer.id)}>ثبت چک</button>
        <button type="button" onClick={() => onAction('edit', customer.id)}>ویرایش اطلاعات مشتری</button>
        <button type="button" onClick={() => onAction('statement', customer.id)}>چاپ صورت‌حساب</button>
      </section>
      <button className="cd-return-customers" type="button" onClick={onBackToCustomers}><ArrowLeft size={15}/> بازگشت به فهرست مشتریان</button>
    </div>
  );
}
