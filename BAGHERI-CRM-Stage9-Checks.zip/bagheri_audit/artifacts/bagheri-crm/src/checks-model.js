export function normalizeCheckSearch(value) {
  return String(value || '').toLocaleLowerCase('fa')
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .trim();
}

export function isCheckDueSoon(row) {
  return row.status === 'pending' && row.dueDiff !== null && row.dueDiff >= 0 && row.dueDiff <= 3;
}

export function isCheckOverdue(row) {
  return row.status === 'pending' && row.dueDiff !== null && row.dueDiff < 0;
}

export function filterCheckRows(rows, side, query, filter, sort) {
  const q = normalizeCheckSearch(query);
  const result = rows.filter((row) => {
    if (row.side !== side) return false;
    if (q) {
      const haystack = normalizeCheckSearch([
        row.partyName, row.checkNumber, row.amount, row.invoiceNumber,
        row.bank, row.note, row.statusLabel,
      ].join(' '));
      if (!haystack.includes(q)) return false;
    }
    if (filter === 'pending' && row.status !== 'pending') return false;
    if (filter === 'cleared' && row.status !== 'cleared') return false;
    if (filter === 'bounced' && (side !== 'supplier' || row.status !== 'bounced')) return false;
    if (filter === 'dueSoon' && !isCheckDueSoon(row)) return false;
    if (filter === 'overdue' && !isCheckOverdue(row)) return false;
    return true;
  });

  result.sort((a, b) => {
    if (sort === 'amountDesc') return b.amount - a.amount || b.sourceIndex - a.sourceIndex;
    if (sort === 'amountAsc') return a.amount - b.amount || b.sourceIndex - a.sourceIndex;
    if (sort === 'newest') {
      if (side === 'customer') return b.createdOrder - a.createdOrder;
      return b.rawDate.localeCompare(a.rawDate) || b.sourceIndex - a.sourceIndex;
    }
    const left = a.dueDateRaw || '';
    const right = b.dueDateRaw || '';
    if (!left && right) return 1;
    if (left && !right) return -1;
    return sort === 'dueDesc' ? right.localeCompare(left) : left.localeCompare(right);
  });
  return result;
}

export function summarizeCheckRows(rows) {
  return {
    count: rows.length,
    faceTotal: rows.reduce((sum, row) => sum + row.amount, 0),
    pendingFace: rows.filter((row) => row.status === 'pending').reduce((sum, row) => sum + row.amount, 0),
    clearedCount: rows.filter((row) => row.status === 'cleared').length,
    pendingCount: rows.filter((row) => row.status === 'pending').length,
    bouncedCount: rows.filter((row) => row.status === 'bounced').length,
    dueSoonCount: rows.filter(isCheckDueSoon).length,
    overdueCount: rows.filter(isCheckOverdue).length,
  };
}
