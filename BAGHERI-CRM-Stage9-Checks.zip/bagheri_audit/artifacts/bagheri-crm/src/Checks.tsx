import { useEffect, useMemo, useState, type ChangeEvent } from 'react';
import {
  ArrowLeft,
  ArrowUpDown,
  Banknote,
  Building2,
  CalendarClock,
  CalendarDays,
  CheckCircle2,
  Clock3,
  FileText,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  X,
} from 'lucide-react';
import {
  filterCheckRows,
  summarizeCheckRows,
  type CheckFilter,
  type CheckRow,
  type CheckSide,
  type CheckSort,
  type ChecksSnapshot,
} from './checks-model';

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const compact = (value: number) => {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return `${fa(amount)} تومان`;
};

const SORT_OPTIONS: Array<{ value: CheckSort; label: string }> = [
  { value: 'dueAsc', label: 'نزدیک‌ترین سررسید' },
  { value: 'dueDesc', label: 'دورترین سررسید' },
  { value: 'newest', label: 'جدیدترین ثبت' },
  { value: 'amountDesc', label: 'بیشترین مبلغ' },
  { value: 'amountAsc', label: 'کمترین مبلغ' },
];

function statusTone(row: CheckRow) {
  if (row.status === 'cleared') return 'is-cleared';
  if (row.status === 'bounced') return 'is-bounced';
  if (row.dueDiff !== null && row.dueDiff < 0) return 'is-overdue';
  if (row.dueDiff !== null && row.dueDiff <= 3) return 'is-soon';
  return 'is-pending';
}

function dueHint(row: CheckRow) {
  if (row.status !== 'pending' || row.dueDiff === null) return '';
  if (row.dueDiff < 0) return `${fa(Math.abs(row.dueDiff))} روز از سررسید گذشته`;
  if (row.dueDiff === 0) return 'سررسید امروز';
  if (row.dueDiff <= 3) return `${fa(row.dueDiff)} روز تا سررسید`;
  return '';
}

export default function Checks({
  snapshot,
  initialSide,
  onOpen,
  onAddCheck,
  onRefresh,
  onSideChange,
}: {
  snapshot: ChecksSnapshot | null;
  initialSide: CheckSide;
  onOpen: (row: CheckRow) => void;
  onAddCheck: () => void;
  onRefresh: () => void;
  onSideChange: (side: CheckSide) => void;
}) {
  const [side, setSide] = useState<CheckSide>(initialSide);
  useEffect(() => setSide(initialSide), [initialSide]);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<CheckFilter>('all');
  const [sort, setSort] = useState<CheckSort>('dueAsc');

  const rows = snapshot?.rows ?? [];
  const sideRows = useMemo(() => rows.filter((row) => row.side === side), [rows, side]);
  const totals = useMemo(() => summarizeCheckRows(sideRows), [sideRows]);
  const filtered = useMemo(() => filterCheckRows(rows, side, query, filter, sort), [rows, side, query, filter, sort]);

  const filters: Array<{ value: CheckFilter; label: string }> = [
    { value: 'all', label: 'همه' },
    { value: 'pending', label: 'در جریان' },
    { value: 'cleared', label: side === 'customer' ? 'وصول‌شده' : 'پرداخت‌شده' },
    ...(side === 'supplier' ? [{ value: 'bounced' as const, label: 'برگشتی' }] : []),
    { value: 'dueSoon', label: 'سررسید نزدیک' },
    { value: 'overdue', label: 'معوق' },
  ];

  const changeSide = (next: CheckSide) => {
    if (next === side) return;
    setSide(next);
    setFilter('all');
    setQuery('');
    setSort('dueAsc');
    onSideChange(next);
  };

  if (!snapshot) {
    return <div className="checks-page" dir="rtl"><div className="customers-loading"><span className="nd-spinner"/> در حال دریافت دفتر چک‌ها…</div></div>;
  }

  return (
    <div className="checks-page" dir="rtl">
      <div className="checks-intro">
        <div>
          <span className="checks-eyebrow">اسناد دریافتنی و پرداختنی</span>
          <h1>چک‌ها</h1>
          <p>پیگیری سررسید و وضعیت چک‌های مشتریان و تأمین‌کنندگان</p>
        </div>
        <span className="checks-total-count">{fa(sideRows.length)} چک</span>
      </div>

      <div className="checks-side-control" role="group" aria-label="نوع چک">
        <button type="button" className={side === 'customer' ? 'is-selected' : ''} aria-pressed={side === 'customer'} onClick={() => changeSide('customer')}>
          <Banknote size={15}/> دریافتی از مشتری
        </button>
        <button type="button" className={side === 'supplier' ? 'is-selected' : ''} aria-pressed={side === 'supplier'} onClick={() => changeSide('supplier')}>
          <Building2 size={15}/> پرداختی به تأمین‌کننده
        </button>
      </div>

      <section className="checks-overview" aria-label="خلاصه چک‌ها">
        <div className="checks-stat is-total">
          <span className="checks-stat-icon"><FileText size={16}/></span>
          <span><small>مبلغ اسمی چک‌ها</small><strong>{compact(totals.faceTotal)}</strong></span>
        </div>
        <div className="checks-stat is-pending">
          <span className="checks-stat-icon"><Clock3 size={16}/></span>
          <span><small>مبلغ اسمی در جریان</small><strong>{compact(totals.pendingFace)}</strong></span>
        </div>
        <div className="checks-stat is-soon">
          <span className="checks-stat-icon"><CalendarClock size={16}/></span>
          <span><small>سررسید نزدیک</small><strong>{fa(totals.dueSoonCount)} مورد</strong></span>
        </div>
        <div className="checks-stat is-overdue">
          <span className="checks-stat-icon"><CalendarDays size={16}/></span>
          <span><small>سررسید گذشته</small><strong>{fa(totals.overdueCount)} مورد</strong></span>
        </div>
      </section>

      <div className="checks-actions-row">
        {side === 'customer' ? (
          <button type="button" className="checks-add-button" onClick={onAddCheck}><Plus size={16}/> ثبت چک دریافتی</button>
        ) : <span className="checks-readonly-note"><ShieldCheck size={14}/> مدیریت از پرونده تأمین‌کننده</span>}
        <button type="button" className="checks-refresh-button" onClick={onRefresh} aria-label="به‌روزرسانی چک‌ها"><RefreshCw size={15}/></button>
      </div>

      <div className="checks-search-wrap">
        <Search size={18}/>
        <input
          value={query}
          onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)}
          placeholder={side === 'customer' ? 'نام مشتری، شماره چک، مبلغ یا فاکتور' : 'نام تأمین‌کننده، شماره چک، بانک یا مبلغ'}
          aria-label="جستجوی چک‌ها"
        />
        {query && <button type="button" onClick={() => setQuery('')} aria-label="پاک کردن جستجو"><X size={16}/></button>}
      </div>

      <div className="checks-toolbar">
        <div className="checks-filters" role="group" aria-label="فیلتر وضعیت چک">
          {filters.map((item) => (
            <button key={item.value} type="button" className={filter === item.value ? 'is-selected' : ''} aria-pressed={filter === item.value} onClick={() => setFilter(item.value)}>
              {item.label}
            </button>
          ))}
        </div>
        <label className="checks-sort">
          <ArrowUpDown size={14}/>
          <select value={sort} onChange={(event) => setSort(event.target.value as CheckSort)} aria-label="مرتب‌سازی چک‌ها">
            {SORT_OPTIONS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
          </select>
        </label>
      </div>

      <div className="checks-list-heading">
        <strong>{side === 'customer' ? 'چک‌های دریافتی' : 'چک‌های پرداختی'}</strong>
        <small>{fa(filtered.length)} مورد</small>
      </div>

      <div className="checks-list">
        {filtered.length ? filtered.map((row) => {
          const hint = dueHint(row);
          const tone = statusTone(row);
          return (
            <button type="button" className="checks-row" key={row.id} onClick={() => onOpen(row)}>
              <span className={`checks-row-icon ${row.side === 'customer' ? 'is-customer' : 'is-supplier'}`}>
                {row.side === 'customer' ? <Banknote size={17}/> : <Building2 size={17}/>}
              </span>
              <span className="checks-row-copy">
                <strong>{row.partyName}</strong>
                <small>
                  {row.checkNumber ? `چک ${row.checkNumber}` : 'بدون شماره'}
                  <i>·</i>
                  سررسید {row.dueDate || 'نامشخص'}
                </small>
                {row.invoiceNumber && <em>فاکتور #{row.invoiceNumber}</em>}
                {hint && <em className="checks-row-warning">{hint}</em>}
              </span>
              <span className="checks-row-amount">
                <strong>{compact(row.amount)}</strong>
                <small className={tone}>{row.statusLabel}</small>
              </span>
              <ArrowLeft className="checks-row-chevron" size={16}/>
            </button>
          );
        }) : (
          <div className="checks-empty">
            <span><Search size={20}/></span>
            <strong>{sideRows.length ? 'چکی با این مشخصات پیدا نشد' : 'هنوز چکی ثبت نشده است'}</strong>
            <p>{sideRows.length ? 'عبارت جستجو یا فیلتر وضعیت را تغییر بده.' : side === 'customer' ? 'چک‌های ثبت‌شده برای مشتریان در این قسمت نمایش داده می‌شوند.' : 'چک‌های ثبت‌شده برای تأمین‌کنندگان در این قسمت نمایش داده می‌شوند.'}</p>
            {(query || filter !== 'all') && <button type="button" onClick={() => { setQuery(''); setFilter('all'); }}>پاک کردن جستجو و فیلتر</button>}
          </div>
        )}
      </div>

      <div className="checks-footer-note">
        <ShieldCheck size={14}/>
        <p>مبالغ این صفحه مبلغ اسمی چک‌ها هستند، نه دریافت یا پرداخت نقدی قطعی. تغییر وضعیت از مسیر رسمی هر چک انجام می‌شود.</p>
      </div>
    </div>
  );
}
