import type { ReactNode } from 'react';
import {
  ArrowRight,
  Banknote,
  Building2,
  CalendarDays,
  CheckCircle2,
  Clock3,
  FileText,
  Landmark,
  Link2,
  ShieldCheck,
  UserRound,
} from 'lucide-react';
import type { CheckRow, ChecksSnapshot } from './checks-model';

const fa = (value: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(value) || 0));
const money = (value: number) => `${fa(value)} تومان`;

function tone(row: CheckRow) {
  if (row.status === 'cleared') return 'is-cleared';
  if (row.status === 'bounced') return 'is-bounced';
  if (row.dueDiff !== null && row.dueDiff < 0) return 'is-overdue';
  if (row.dueDiff !== null && row.dueDiff <= 3) return 'is-soon';
  return 'is-pending';
}

function dueMessage(row: CheckRow) {
  if (row.status !== 'pending' || row.dueDiff === null) return '';
  if (row.dueDiff < 0) return `${fa(Math.abs(row.dueDiff))} روز از تاریخ سررسید گذشته است.`;
  if (row.dueDiff === 0) return 'سررسید این چک امروز است.';
  if (row.dueDiff <= 3) return `${fa(row.dueDiff)} روز تا سررسید باقی مانده است.`;
  return '';
}

function Field({ label, value, icon }: { label: string; value: string; icon?: ReactNode }) {
  return (
    <div className="check-detail-field">
      <small>{icon}{label}</small>
      <strong>{value || '—'}</strong>
    </div>
  );
}

export default function CheckDetail({
  snapshot,
  checkId,
  onBack,
  onNavigate,
  onToggleCustomerStatus,
}: {
  snapshot: ChecksSnapshot | null;
  checkId: string;
  onBack: () => void;
  onNavigate: (path: string) => void;
  onToggleCustomerStatus: (rawId: string) => boolean;
}) {
  const row = snapshot?.rows.find((item) => item.id === checkId) || null;
  if (!row) {
    return (
      <div className="check-detail-page" dir="rtl">
        <button type="button" className="check-detail-back" onClick={onBack}><ArrowRight size={17}/> بازگشت به دفتر چک‌ها</button>
        <div className="checks-empty"><span><FileText size={20}/></span><strong>چک پیدا نشد</strong><p>ممکن است این چک حذف شده باشد یا اطلاعات آن هنوز همگام نشده باشد.</p></div>
      </div>
    );
  }

  const hint = dueMessage(row);
  const isCustomer = row.side === 'customer';

  return (
    <div className="check-detail-page" dir="rtl">
      <button type="button" className="check-detail-back" onClick={onBack}><ArrowRight size={17}/> دفتر چک‌ها</button>

      <div className="check-detail-heading">
        <span className="check-detail-eyebrow">{isCustomer ? 'چک دریافتی از مشتری' : 'چک پرداختی به تأمین‌کننده'}</span>
        <h1>{row.checkNumber ? `چک شماره ${row.checkNumber}` : 'جزئیات چک'}</h1>
        <p>{row.partyName}</p>
      </div>

      <section className="check-detail-amount-card">
        <span className="check-detail-amount-icon">{isCustomer ? <Banknote size={19}/> : <Landmark size={19}/>}</span>
        <small>مبلغ اسمی چک</small>
        <strong>{money(row.amount)}</strong>
        <span className={`check-detail-status ${tone(row)}`}>
          {row.status === 'cleared' ? <CheckCircle2 size={14}/> : <Clock3 size={14}/>}
          {row.statusLabel}
        </span>
      </section>

      {hint && <div className={`check-detail-due-note ${row.dueDiff !== null && row.dueDiff < 0 ? 'is-overdue' : 'is-soon'}`}><CalendarDays size={17}/><span>{hint}</span></div>}
      {row.status === 'bounced' && <div className="check-detail-bounced-note"><ShieldCheck size={16}/><span>این چک در منبع رسمی با وضعیت برگشتی ثبت شده است. مبلغ اسمی آن از مبلغ پرداخت‌شده جدا نگه داشته می‌شود.</span></div>}

      <section className="check-detail-section">
        <h2>مشخصات چک</h2>
        <div className="check-detail-fields">
          <Field label="شماره چک" value={row.checkNumber}/>
          <Field label="تاریخ سررسید" value={row.dueDate}/>
          <Field label={isCustomer ? 'تاریخ فاکتور مرتبط' : 'تاریخ صدور'} value={isCustomer ? row.invoiceDate : row.issueDate}/>
          {!isCustomer && <Field label="بانک" value={row.bank}/>}
          <Field label="وضعیت ثبت‌شده" value={row.statusLabel}/>
          {row.note && <Field label="توضیح" value={row.note}/>}
        </div>
      </section>

      <section className="check-detail-section">
        <h2>طرف حساب و ارتباطات</h2>
        <div className="check-detail-links">
          <button type="button" onClick={() => onNavigate(`/${isCustomer ? 'customer' : 'supplier'}?id=${encodeURIComponent(row.partyId)}`)}>
            {isCustomer ? <UserRound size={17}/> : <Building2 size={17}/>}
            <span><strong>{isCustomer ? 'پرونده مشتری' : 'پرونده تأمین‌کننده'}</strong><small>{row.partyName}</small></span>
            <Link2 size={15}/>
          </button>
          {isCustomer && row.invoiceId && (
            <button type="button" onClick={() => onNavigate(`/invoice?id=${encodeURIComponent(row.invoiceId)}`)}>
              <FileText size={17}/>
              <span><strong>فاکتور مرتبط</strong><small>شماره {row.invoiceNumber || '—'}</small></span>
              <Link2 size={15}/>
            </button>
          )}
        </div>
      </section>

      <section className="check-detail-actions">
        {isCustomer ? (
          <button type="button" className="check-detail-primary-action" onClick={() => onToggleCustomerStatus(row.rawId)} disabled={!row.rawId}>
            <CheckCircle2 size={16}/>{row.status === 'cleared' ? 'بازگرداندن به وضعیت در جریان' : 'ثبت وصول چک'}
          </button>
        ) : (
          <button type="button" className="check-detail-primary-action" onClick={() => onNavigate(`/supplier?id=${encodeURIComponent(row.partyId)}`)}>
            <Building2 size={16}/> مدیریت وضعیت و مشخصات چک
          </button>
        )}
        <p><ShieldCheck size={13}/> عملیات وضعیت و ذخیره‌سازی از مسیر رسمی موجود برنامه انجام می‌شود.</p>
      </section>
    </div>
  );
}
