import { useMemo, type CSSProperties } from 'react';
import {
  ArrowLeft, ArrowUpLeft, AlertTriangle, Banknote, CalendarCheck,
  ChartNoAxesCombined, ClipboardList, Package, Plus, ReceiptText,
  RefreshCw, ShoppingBag, UsersRound, Wallet,
} from 'lucide-react';

export type DashboardSnapshot = {
  today: { sales: number; invoices: number; visits: number; received: number };
  month: { sales: number; profit: number; count: number; target: number; progress: number; delta: number | null; day: number; days: number };
  totals: { customerDebt: number; supplierDebt: number; stockValue: number; customers: number; products: number; checks: number };
  actions: Array<{ id: string; name: string; kind: string; action: string; reason: string; urgency: string; path: string }>;
  watches: Array<{ id: string; name: string; product: string; reason: string; severity: string }>;
  invoices: Array<{ id: string; number: string; customer: string; date: string; total: number }>;
  visits: Array<{ customerId: string; name: string; date: string; result: string }>;
  updatedAt: number;
};

const fa = (n: number) => new Intl.NumberFormat('fa-IR').format(Math.round(Number(n) || 0));
const money = (n: number) => `${fa(n)} تومان`;
const compact = (n: number) => {
  const v = Number(n) || 0;
  if (Math.abs(v) >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(1).replace(/\.0$/, '')} میلیارد`;
  if (Math.abs(v) >= 1_000_000) return `${(v / 1_000_000).toFixed(1).replace(/\.0$/, '')} میلیون`;
  return money(v);
};

export default function Dashboard({ snapshot, onNavigate, onRefresh }: {
  snapshot: DashboardSnapshot | null;
  onNavigate: (path: string) => void;
  onRefresh: () => void;
}) {
  const today = useMemo(() => new Intl.DateTimeFormat('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date()), []);
  const data = snapshot;
  return (
    <div className="new-dashboard" dir="rtl">
      <div className="nd-welcome">
        <div>
          <div className="nd-eyebrow">دفتر کار روزانه</div>
          <h1>امروز چه کار کنم؟</h1>
          <p>{today} · نمای کلی کسب‌وکار باقری</p>
        </div>
        <button className="nd-refresh" onClick={onRefresh} aria-label="به‌روزرسانی اطلاعات"><RefreshCw size={17}/></button>
      </div>

      {!data ? (
        <div className="nd-loading"><span className="nd-spinner"/> در حال دریافت اطلاعات دفتر کار…</div>
      ) : <>
        <section className="nd-today" aria-label="خلاصه امروز">
          <div className="nd-section-heading"><span>عملکرد امروز</span><small>تا این لحظه</small></div>
          <div className="nd-today-grid">
            <div className="nd-today-primary"><span>فروش امروز</span><strong>{compact(data.today.sales)}</strong><small>{fa(data.today.invoices)} فاکتور ثبت‌شده</small></div>
            <div className="nd-today-stat"><span className="nd-stat-icon green"><Wallet size={17}/></span><small>دریافتی امروز</small><strong>{compact(data.today.received)}</strong></div>
            <div className="nd-today-stat"><span className="nd-stat-icon blue"><CalendarCheck size={17}/></span><small>ویزیت امروز</small><strong>{fa(data.today.visits)}</strong></div>
          </div>
        </section>

        <section className="nd-target">
          <div className="nd-target-copy">
            <span className="nd-section-kicker">هدف فروش این ماه</span>
            <strong>{data.month.target > 0 ? compact(data.month.target) : 'هنوز تعیین نشده'}</strong>
            <span>{data.month.target > 0 ? `${compact(data.month.sales)} فروش تا امروز` : 'برای تعیین هدف، از بخش گزارش‌ها اقدام کنید'}</span>
            {data.month.target > 0 && <small>{data.month.progress}% از هدف · روز {fa(data.month.day)} از {fa(data.month.days)}</small>}
          </div>
          <div className="nd-ring" style={{ '--progress': `${Math.min(100, Math.max(0, data.month.progress))}%` } as CSSProperties}>
            <div><strong>{data.month.target > 0 ? fa(data.month.progress) : '—'}</strong><small>درصد</small></div>
          </div>
        </section>

        <section className="nd-actions-section">
          <div className="nd-section-heading"><span>کارهای پیشنهادی امروز</span><button onClick={() => onNavigate('/customers')}>مشتریان <ArrowLeft size={14}/></button></div>
          {data.actions.length ? <div className="nd-action-list">{data.actions.slice(0, 4).map((a, i) => (
            <button className="nd-action-row" key={`${a.id}-${i}`} onClick={() => onNavigate(a.path)}>
              <span className={`nd-priority p-${a.urgency}`}>{a.urgency === 'critical' ? <AlertTriangle size={17}/> : <ArrowUpLeft size={17}/>}</span>
              <span className="nd-action-copy"><strong>{a.name}</strong><small>{a.action || 'پیگیری مشتری'}</small>{a.reason && <em>{a.reason}</em>}</span>
              <ArrowLeft className="nd-row-arrow" size={16}/>
            </button>
          ))}</div> : <div className="nd-empty"><span>✓</span><div><strong>کار ضروری ثبت نشده</strong><small>وضعیت مشتری‌ها را می‌توانی از بخش مشتریان بررسی کنی.</small></div></div>}
        </section>

        {data.watches.length > 0 && <section className="nd-watches">
          <div className="nd-section-heading"><span>هشدارهای نیازمند توجه</span><button onClick={() => onNavigate('/watches')}>همه هشدارها <ArrowLeft size={14}/></button></div>
          {data.watches.slice(0, 2).map(w => <button className="nd-watch-row" key={w.id} onClick={() => onNavigate(`/watch?id=${encodeURIComponent(w.id)}`)}><span className="nd-watch-dot"/><span><strong>{w.name} · {w.product}</strong><small>{w.reason}</small></span><ArrowLeft size={15}/></button>)}
        </section>}

        <section className="nd-finance">
          <div className="nd-section-heading"><span>وضعیت مالی</span><small>ماه جاری و مانده‌ها</small></div>
          <div className="nd-finance-list">
            <div><span className="nd-fin-icon"><ChartNoAxesCombined size={17}/></span><span>سود این ماه</span><strong>{compact(data.month.profit)}</strong></div>
            <div><span className="nd-fin-icon"><Package size={17}/></span><span>ارزش موجودی</span><strong>{compact(data.totals.stockValue)}</strong></div>
            <button onClick={() => onNavigate('/customers?filter=debt')}><span className="nd-fin-icon"><Wallet size={17}/></span><span>بدهی مشتریان</span><strong>{compact(data.totals.customerDebt)}</strong><ArrowLeft size={15}/></button>
            <button onClick={() => onNavigate('/suppliers')}><span className="nd-fin-icon"><Banknote size={17}/></span><span>بدهی تأمین‌کنندگان</span><strong>{compact(data.totals.supplierDebt)}</strong><ArrowLeft size={15}/></button>
          </div>
        </section>

        <section className="nd-quick">
          <div className="nd-section-heading"><span>اقدام سریع</span><small>میان‌برهای روزانه</small></div>
          <div className="nd-quick-grid">
            <button onClick={() => onNavigate('/invoices')}><span><Plus size={19}/></span><strong>فاکتور جدید</strong></button>
            <button onClick={() => onNavigate('/payments')}><span><Wallet size={19}/></span><strong>ثبت دریافت</strong></button>
            <button onClick={() => onNavigate('/visits')}><span><CalendarCheck size={19}/></span><strong>ثبت ویزیت</strong></button>
            <button onClick={() => onNavigate('/evaluation')}><span><ShoppingBag size={19}/></span><strong>ارزیابی مغازه</strong></button>
          </div>
        </section>

        <section className="nd-recent">
          <div className="nd-section-heading"><span>آخرین فاکتورها</span><button onClick={() => onNavigate('/invoices')}>مشاهده همه <ArrowLeft size={14}/></button></div>
          {data.invoices.length ? data.invoices.slice(0, 4).map(inv => <button className="nd-recent-row" key={inv.id} onClick={() => onNavigate(`/invoice?id=${encodeURIComponent(inv.id)}`)}><span className="nd-recent-icon"><ReceiptText size={17}/></span><span><strong>{inv.customer}</strong><small>فاکتور {inv.number ? `شماره ${inv.number}` : ''} · {inv.date}</small></span><b>{compact(inv.total)}</b></button>) : <div className="nd-empty"><ClipboardList size={19}/> هنوز فاکتوری ثبت نشده است.</div>}
        </section>

        <div className="nd-footer-note"><UsersRound size={14}/> {fa(data.totals.customers)} مشتری · {fa(data.totals.products)} کالا · {fa(data.totals.checks)} چک ثبت‌شده</div>
      </>}
    </div>
  );
}
