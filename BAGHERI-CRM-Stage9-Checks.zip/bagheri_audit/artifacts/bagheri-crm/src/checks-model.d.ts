export type CheckSide = 'customer' | 'supplier';
export type CheckStatus = 'pending' | 'cleared' | 'bounced';
export type CheckFilter = 'all' | 'pending' | 'cleared' | 'bounced' | 'dueSoon' | 'overdue';
export type CheckSort = 'dueAsc' | 'dueDesc' | 'amountDesc' | 'amountAsc' | 'newest';

export interface CheckRow {
  id: string;
  rawId: string;
  side: CheckSide;
  partyName: string;
  partyId: string;
  invoiceId: string;
  invoiceNumber: string;
  invoiceDate: string;
  invoiceDateRaw: string;
  issueDate: string;
  issueDateRaw: string;
  dueDate: string;
  dueDateRaw: string;
  dueDiff: number | null;
  amount: number;
  status: CheckStatus;
  statusLabel: string;
  checkNumber: string;
  bank: string;
  note: string;
  rawDate: string;
  createdOrder: number;
  sourceIndex: number;
}

export interface ChecksSnapshot {
  rows: CheckRow[];
  updatedAt: number;
}

export function normalizeCheckSearch(value: string): string;
export function isCheckDueSoon(row: CheckRow): boolean;
export function isCheckOverdue(row: CheckRow): boolean;
export function filterCheckRows(rows: CheckRow[], side: CheckSide, query: string, filter: CheckFilter, sort: CheckSort): CheckRow[];
export function summarizeCheckRows(rows: CheckRow[]): {
  count: number;
  faceTotal: number;
  pendingFace: number;
  clearedCount: number;
  pendingCount: number;
  bouncedCount: number;
  dueSoonCount: number;
  overdueCount: number;
};
